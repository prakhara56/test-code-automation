import streamlit as st
import json
import os
import asyncio
from workflow import run_workflow

# -------------------
# Helper functions
# -------------------
def main(input_path):
    """Run the workflow using the provided input file."""
    with open(input_path, 'r', encoding="utf-8") as f:
        inp = json.load(f)
    testcase = inp['testcase']
    recorded_steps = inp['action_input']
    config = {
        "configurable": {
            "thread_id": "mock_run_1",
            "n_search": 10,
            "index_path": "Repo_Index/repo_index.json",
            'clone_dir': r"C:\Users\prakhar.agarwal\Downloads\repos",
            'repo_name': "BAWTestAutomation",
        }
    }
    output = asyncio.run(run_workflow(testcase, recorded_steps, config))
    return output

def save_output(output, input_filename):
    """Save the workflow output in the outputs folder with _output appended to the input filename."""
    output_filename = os.path.splitext(input_filename)[0] + "_output.json"
    output_path = os.path.join("outputs", output_filename)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=4)
    return output_path

def display_mapping(mapping_data):
    """Display mapping details from the output JSON."""
    st.write(mapping_data.get("testcase",[]))
    st.divider()
    # Relevant snippets mapping: feature step queries and corresponding step definitions
    # for i, item in enumerate(mapping_data.get("relevant_snippets", [])):
    #     with st.expander(f"🔹 Step {i+1}: {item['query']}"):
    #         st.markdown(f"**📝 Feature Step Query:** `{item['query']}`")
    #         snippets = item.get("snippets", [])
    #         if not snippets:
    #             st.info("No matching snippets found.")
    #         for j, snippet in enumerate(snippets):
    #             st.markdown(f"##### 📌 Step Definition #{j+1}")
    #             st.code(snippet["text"], language="java")
    #             st.caption(f"📁 `{snippet['path']}`  |  🔍 Match Score: `{snippet['match_score']:.4f}`")

    # st.divider()

    # Feature file block (generated feature file)
    st.subheader("🔖 Feature Files")
    for feature in mapping_data.get("feature_files", []):
        st.markdown(f"### 📄 {feature['file_name']}")
        st.caption(f"📁 {feature['file_path']}")
        st.code(feature["code"], language="text")

        st.markdown("Steps which did not match to Codebase")
        st.code("\n".join(feature["gherkin_steps_which_do_not_have_step_function"]), language="text")

    st.divider()

    # Step function file block
    st.subheader("📘 Step Definition Files")
    for step in mapping_data.get("step_functions", []):
        st.markdown(f"### 📄 {step['file_name']}")
        st.caption(f"📁 {step['file_path']}")
        st.code(step["code"]["step_function"], language="java")

    st.divider()

    # Page object file block
    st.subheader("📙 Page Object Files")
    for page in mapping_data.get("page_functions", []):
        functions = page["code"]["page_functions"]
        for file_name, code in functions.items():
            st.markdown(f"### 📄 {file_name}")
            st.caption(f"📁 {page['file_path']}")
            st.code(code, language="java")

# -------------------
# Sidebar: Mode selection
# -------------------
st.sidebar.title("Menu")
mode = st.sidebar.radio("Select Mode", options=["Run Workflow", "View Outputs & Mapping"])

# -------------------
# Mode 1: Run Workflow
# -------------------
if mode == "Run Workflow":
    st.header("🚀 Run Workflow")
    input_folder = "inputs"
    if not os.path.exists(input_folder):
        st.error(f"Inputs folder '{input_folder}' not found.")
    else:
        input_files = [f for f in os.listdir(input_folder) if f.endswith(".json")]
        if not input_files:
            st.info("No input JSON files found in the inputs folder.")
        else:
            selected_input = st.sidebar.selectbox("Select Input File", input_files)
            if st.sidebar.button("Run Workflow"):
                input_path = os.path.join(input_folder, selected_input)
                with st.spinner("Running workflow..."):
                    output = main(input_path)
                    saved_output_path = save_output(output, selected_input)
                st.success(f"Output saved to `{saved_output_path}`")
                st.subheader("Workflow Output")
                st.code(json.dumps(output, indent=4), language="json")

# -------------------
# Mode 2: View Outputs & Mapping
# -------------------
elif mode == "View Outputs & Mapping":
    st.header("📂 View Outputs & Mapping Details")
    output_folder = "outputs_confirmation"
    if not os.path.exists(output_folder):
        st.error(f"Outputs folder '{output_folder}' not found.")
    else:
        output_files = [f for f in os.listdir(output_folder) if f.endswith(".json")]
        if not output_files:
            st.info("No output JSON files found in the outputs folder.")
        else:
            selected_output = st.sidebar.selectbox("Select Output File", output_files)
            if st.sidebar.button("View Output"):
                output_path = os.path.join(output_folder, selected_output)
                try:
                    with open(output_path, "r", encoding="utf-8") as f:
                        out_data = json.load(f)
                except Exception as e:
                    st.error(f"Error reading file: {e}")
                else:
                    # If the output file has mapping keys, display the mapping view.
                    if "relevant_snippets" in out_data:
                        st.subheader(f"Mapping Details: `{selected_output}`")
                        display_mapping(out_data)
                    else:
                        st.subheader(f"Raw Output: `{selected_output}`")
                        st.code(json.dumps(out_data, indent=4), language="json")
