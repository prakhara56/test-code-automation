import streamlit as st
import os
import json

st.header("📂 View Outputs & Mapping Details")
output_folder = "outputs\\Testing_React_outputs"

if not os.path.exists(output_folder):
    st.error(f"Outputs folder '{output_folder}' not found.")
else:
    output_files = [f for f in os.listdir(output_folder) if f.endswith(".json")]
    if not output_files:
        st.info("No output JSON files found in the outputs folder.")
    else:
        selected_output = st.sidebar.selectbox("Select Output File", output_files)
        if st.sidebar.button("View Output") or "out_data" not in st.session_state or st.session_state.get("current_file") != selected_output:
            output_path = os.path.join(output_folder, selected_output)
            try:
                with open(output_path, "r", encoding="utf-8") as f:
                    out_data = json.load(f)
                st.session_state.out_data = out_data
                st.session_state.current_file = selected_output
                st.session_state.msg_idx = 0
                st.session_state.selected_role = None
            except Exception as e:
                st.error(f"Error reading file: {e}")

        # Now, continue if data is loaded in session state
        if "out_data" in st.session_state:
            conv_data = st.session_state.out_data

            # 1. Collect unique roles
            roles = list({msg['role'] for msg in conv_data})

            # 2. Sidebar for selecting role
            selected_role = st.sidebar.radio("Select role to view:", roles, 
                                             index=roles.index(st.session_state.get("selected_role", roles[0])) 
                                             if st.session_state.get("selected_role") in roles else 0)
            st.session_state.selected_role = selected_role

            # 3. Filter messages for that role
            role_messages = [msg for msg in conv_data if msg['role'] == selected_role]
            total = len(role_messages)

            # 4. Maintain navigation state
            if "msg_idx" not in st.session_state or st.session_state.get("last_role") != selected_role:
                st.session_state.msg_idx = 0
                st.session_state.last_role = selected_role

            col1, col2, col3 = st.columns([1, 6, 1])
            with col1:
                if st.button("Previous") and st.session_state.msg_idx > 0:
                    st.session_state.msg_idx -= 1
            with col3:
                if st.button("Next") and st.session_state.msg_idx < total - 1:
                    st.session_state.msg_idx += 1

            current_idx = st.session_state.msg_idx

            st.markdown(f"**Role:** `{selected_role}` &nbsp;&nbsp; **Message {current_idx+1} of {total}**")
            st.code(role_messages[current_idx]["content"], language="markdown")

            meta_info = {k: v for k, v in role_messages[current_idx].items() if k not in ["content", "role"]}
            if meta_info:
                st.markdown("**Metadata:**")
                st.json(meta_info)
