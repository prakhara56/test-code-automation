from loguru import logger
import json

from typing_extensions import TypedDict
from typing import List, Annotated, Dict, Any
from langgraph.graph.message import add_messages

from langchain_core.prompts import PromptTemplate
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.output_parsers import StrOutputParser,JsonOutputParser
from code_manager.llm import llm


plan_generation_prompt = PromptTemplate.from_template("""
You are an expert QA planner generating queries to retrieve code snippets from a Java Selenium codebase.

Your task:
- Given a test case and action_input metadata, generate precise search queries.
- Each query should describe a user action in a way that can be matched to Java Selenium code.

Use DOM data like tagName, outerHTML, id, text.

Respond in JSON:
{{
  "plan": [
    {{ "step": "click login button", "query": "Find Java method that clicks a button with id 'loginBtn'" }}
  ]
}}

Test Case:
{testcase}

Action Input:
{action_input}
""")


reviewer_prompt_template = PromptTemplate.from_template("""
You are a senior QA architect reviewing a plan of code search queries, generated for a Java Selenium project using the Cucumber framework.

The purpose of this plan is to identify or generate matching Java methods (e.g., step definitions, page methods, or utilities) that correspond to the test case steps and recorded actions.

Your tasks:

1. **Verify the correctness of each query**:
   - Does it clearly describe the action based on the provided HTML or selectors?
   - Would it help find the right method in a Java Selenium codebase?

2. **Think in terms of automation**:
   - For each query, consider whether a Cucumber step definition or a page object function would likely exist.
   - Check if anything is missing that’s common in automation flows (e.g., wait conditions, setup, teardown, validations).

3. **Suggest improvements**:
   - Rewrite vague queries to be more specific and actionable.
   - Add any missing queries that a Java Selenium Cucumber framework would typically require (e.g., asserting an element, navigation, hooks, shared login steps).

4. **If the plan is solid and complete**, respond with the word `FINISHED`.

Respond in the same JSON structure as the original plan.

Plan to review:
{plan_json}
""")




# Simulate nodes
def planner_node(state):
    prompt = plan_generation_prompt | llm | StrOutputParser()
    logger.info("planner_node invoked")
    plan_json = prompt.invoke({
        "testcase": state["testcase"],
        "action_input": state["action_input"]
    })
    print("planner:\n",plan_json)
    return {"messages": [AIMessage(content=plan_json)]}

def reviewer_node(state):
    plan_json = state["messages"][-1].content
    prompt = reviewer_prompt_template | llm | StrOutputParser()
    logger.info("reviewer_node invoked")
    review_response = prompt.invoke({"plan_json": plan_json})
    print("reviewer:\n",review_response)
    return {"messages": [HumanMessage(content=review_response)]}

def should_continue(state):
    last_msg = state["messages"][-1].content
    if "FINISHED" in last_msg.upper():
        return "end"
    elif len(state["messages"]) > 10:
        return "end"
    else:
        return "continue"



class PlanState(TypedDict):
    messages: Annotated[List, add_messages]
    testcase: str
    action_input: List[Any]

builder = StateGraph(PlanState)
builder.add_node("planner", planner_node)
builder.add_node("reviewer", reviewer_node)

builder.add_edge(START, "planner")
builder.add_edge("planner", "reviewer")
builder.add_conditional_edges("reviewer", should_continue, {
    "continue": "planner",
    "end": END
})

plan_chat_graph = builder.compile()



if __name__ == "__main__":


    with open('outputs/test_run.json','r') as f:
        test_run = json.load(f)

    testcase = test_run["testcase"]
    action_input = test_run["recorded_steps"]

    inputs = {
        "testcase": testcase,
        "action_input": action_input,
        "messages": []
    }

    # for step in plan_chat_graph.stream(inputs):
    #     if END not in step:
    #         print(step["messages"][-1])
    #         print("=" * 50)

    step = plan_chat_graph.invoke(inputs)

    print("\n✅ Final plan:")
    print(step["messages"][-1].content)

