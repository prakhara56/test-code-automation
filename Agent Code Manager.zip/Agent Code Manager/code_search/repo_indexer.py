# semantic_code_search/repo_indexer.py
import os
import json
import tempfile
import shutil
import subprocess, time, re
from loguru import logger
from git import Repo
from .tree_node import TreeNode
from .tree_sitter_parsers import parse_file
from .utils import remove_readonly, get_default_branch

class RepoIndexer:
    def __init__(self, repo_url= None, clone_dir=None, repo_dir=""):
        """
        repo_url: URL of the Git/Azure repository.
        config: Dict with configuration (e.g. file_extensions).
        clone_dir: Optional directory for cloning.
        """
        
        self.repo_dir = repo_dir if os.path.exists(repo_dir) else None
        self.repo_url = repo_url
        self.clone_dir = clone_dir or tempfile.mkdtemp(prefix="repo_index_")
        if not os.path.exists(self.clone_dir):
            os.makedirs(self.clone_dir)
        elif not os.path.isdir(self.clone_dir):
            raise ValueError(f"Clone directory {self.clone_dir} already exists and is not a directory.")
        logger.debug(f"Using clone directory: {self.clone_dir}")
        self.index = {}  # Flat index: { file_path: metadata }
        self.hierarchical_index = TreeNode(name=os.path.basename(self.clone_dir), path=self.clone_dir, node_type='folder')
        TreeNode.base_path = self.clone_dir
        logger.info(f"Initialized RepoIndexer with clone_dir: {self.clone_dir}")

    def clone_repository(self):
        """
        Clone (or update) the repository.
        """
        if not os.path.exists(self.clone_dir):
            os.makedirs(self.clone_dir)

        existing_repo = None
        for subdir in os.listdir(self.clone_dir):
            full_path = os.path.join(self.clone_dir, subdir)
            if os.path.isdir(full_path) and os.path.isdir(os.path.join(full_path, ".git")):
                try:
                    result = subprocess.run(
                        ["git", "-C", full_path, "remote", "get-url", "origin"],
                        capture_output=True, text=True, check=True
                    )
                    remote_url = result.stdout.strip()
                    if remote_url == self.repo_url:
                        existing_repo = full_path
                        break
                except subprocess.CalledProcessError:
                    shutil.rmtree(full_path, onexc=remove_readonly)
        if existing_repo:
            try:
                logger.info(f"Repository found at {existing_repo}. Updating...")
                subprocess.run(["git", "-C", existing_repo, "fetch"], check=True)
                default_branch = get_default_branch(existing_repo)
                if not default_branch:
                    raise Exception("Could not determine default branch.")
                subprocess.run(["git", "-C", existing_repo, "reset", "--hard", f"origin/{default_branch}"], check=True)
                subprocess.run(["git", "-C", existing_repo, "clean", "-fd"], check=True)
                self.repo_dir = existing_repo
                logger.info(f"Repository updated at {self.repo_dir}")
                return existing_repo
            except subprocess.CalledProcessError as e:
                logger.error(f"Failed to update existing repository: {e}")
                shutil.rmtree(existing_repo)
        # Fresh clone
        max_attempts = 3
        for attempt in range(1, max_attempts + 1):
            try:
                logger.info(f"Attempt {attempt}: Cloning {self.repo_url}")
                result = subprocess.run(
                    ["git", "clone", self.repo_url],
                    cwd=self.clone_dir,
                    check=True,
                    # capture_output=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True
                )
                print("Terminal Result \n",result.stderr)
                match = re.search(r"Cloning into '([^']+)'", result.stdout)
                if match:
                    repo_folder = match.group(1)
                    self.repo_dir = os.path.join(self.clone_dir, repo_folder)
                    logger.info(f"Repository cloned to {self.repo_dir}")
                    return self.repo_dir
                else:
                    return None
            except subprocess.CalledProcessError as e:
                time.sleep(2)
                logger.error(f"Attempt {attempt} failed: {e}")
        raise Exception(f"Failed to clone repository from {self.repo_url} after {max_attempts} attempts.")

    def index_file(self, file_path, file_extensions:list = None):
        """
        Use Tree-sitter parsing for supported file extensions.
        """
        logger.debug(f"Indexing file: {file_path}")
        if file_extensions is None:
            file_extensions = [".py", ".js", ".ts", ".java"]
        else :
            file_extensions = file_extensions
        metadata = parse_file(file_path,file_extensions)
        file_node = TreeNode(name=os.path.basename(file_path), path=file_path, node_type="file")
        file_node.metadata = metadata
        current_folder_node = self.get_tree_node(os.path.dirname(file_path))
        current_folder_node.add_child(file_node)
        self.index[file_path] = metadata
        return metadata

    def build_index(self, file_extensions:list = None):
        """
        Recursively build the index for the cloned repository.
        """
        logger.info(f"Building index for repository in {self.repo_dir}")
        for root, dirs, files in os.walk(self.repo_dir):
            dirs[:] = [d for d in dirs if d != '.git']
            current_folder_node = self.get_tree_node(root)
            for file in files:
                file_path = os.path.join(root, file)
                self.index_file(file_path, file_extensions)

    def get_tree_node(self, path):
        rel_path = os.path.relpath(path, self.clone_dir)
        if rel_path == ".":
            return self.hierarchical_index
        parts = rel_path.split(os.sep)
        current_node = self.hierarchical_index
        for part in parts:
            found = False
            for child in current_node.children:
                if child.name == part and child.node_type == "folder":
                    current_node = child
                    found = True
                    break
            if not found:
                new_node = TreeNode(name=part, path=os.path.join(current_node.path, part), node_type="folder")
                current_node.add_child(new_node)
                current_node = new_node
        return current_node

    def save_index(self, output_path="repo_index.json"):
        index_dict = self.hierarchical_index.to_dict()
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(index_dict, f, indent=4)
        logger.info(f"Index saved to {output_path}")

    def cleanup(self):
        if os.path.exists(self.clone_dir):
            shutil.rmtree(self.clone_dir)
            logger.info(f"Cleaned up cloned repository at {self.clone_dir}")

if __name__ == "__main__":
    config = {
        "file_extensions": [".py", ".js", ".ts", ".java"]
    }
    repo_url = "https://github.com/your_org/your_repo.git"  # Replace with your URL
    clone_dir = "repo_clone_dir"
    indexer = RepoIndexer(repo_url=repo_url, config=config, clone_dir=clone_dir)
    repo_path = indexer.clone_repository()
    indexer.build_index()
    indexer.save_index("Repo_Index/repo_index.json")
