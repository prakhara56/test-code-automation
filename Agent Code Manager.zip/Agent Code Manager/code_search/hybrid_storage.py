# semantic_code_search/hybrid_storage.py
import os
import gzip
import pickle
from .tree_node import TreeNode
from loguru import logger
from typing import Tuple,Dict

def hybrid_load(index_path:str, embeddings_path:str)->Tuple[TreeNode,Dict]:   

    logger.info(f"Loading hybrid index from {index_path} and embeddings from {embeddings_path}")

    tree_root = TreeNode.load_from_file(index_path)
    with gzip.open(embeddings_path, "rb") as f:
        emb_data = pickle.load(f)
    
    return tree_root, emb_data
