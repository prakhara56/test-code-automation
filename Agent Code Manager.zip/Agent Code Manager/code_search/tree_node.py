# semantic_code_search/tree_node.py
import json
import os
from langchain_core.documents import Document
from loguru import logger

def test_parent_child_connections(node):
    parent_name = node.parent.name if node.parent else "None"
    print(f"Node: {node.name}, Parent: {parent_name}")
    for child in node.children:
        test_parent_child_connections(child)

class TreeNode:
    base_path = None

    def __init__(self, name, path, node_type='folder'):
        self.name = name
        self.path = path
        self.node_type = node_type
        self.children = []
        self.metadata = None
        self.parent = None

    def add_child(self, child):
        child.parent = self
        self.children.append(child)

    def to_dict(self):
        relative_path = self.path
        if TreeNode.base_path and self.path.startswith(TreeNode.base_path):
            relative_path = ".\\" + self.path[len(TreeNode.base_path):].lstrip(os.sep)
        result = {"name": self.name, "path": relative_path, "type": self.node_type}
        if self.metadata:
            result["metadata"] = self.metadata
        if self.children:
            result["children"] = [child.to_dict() for child in self.children]
        return result

    @classmethod
    def from_json(cls, json_data):
        node = cls(json_data["name"], json_data["path"], json_data["type"])
        if node.node_type == "file" and "metadata" in json_data:
            node.metadata = json_data["metadata"]
        if node.node_type == "folder" and "children" in json_data:
            for child_data in json_data["children"]:
                child = cls.from_json(child_data)
                node.add_child(child)
        return node

    @classmethod
    def load_from_file(cls, file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                json_data = json.load(f)
            return cls.from_json(json_data)
        except Exception as e:
            logger.error(f"Error loading JSON from {file_path}: {e}")
            return None

    def print_tree(self, level=0):
        indent = "  " * level
        logger.info(f"{indent}- {self.name} ({self.node_type})")
        if self.node_type == "file" and self.metadata:
            logger.info(f"{indent}  Metadata: {self.metadata}")
        for child in self.children:
            child.print_tree(level + 1)

    def print_directory_structure(self, indent="", last=True):
        connector = "└── " if last else "├── "
        print(indent + connector + f"{self.name} ({self.node_type})")
        indent += "    " if last else "│   "
        for i, child in enumerate(self.children):
            child.print_directory_structure(indent, i == len(self.children) - 1)

    def get_directory_structure(self, indent="", last=True) -> str:
        lines = []
        connector = "└── " if last else "├── "
        lines.append(indent + connector + f"{self.name} ({self.node_type})")
        indent += "    " if last else "│   "
        for i, child in enumerate(self.children):
            lines.append(child.get_directory_structure(indent, i == len(self.children) - 1))
        return "\n".join(lines)

    def create_embeddings_metadata(self,metadata_list = None):
        if metadata_list is None:
            metadata_list = []

        if self.node_type == "file" and self.metadata:
            new_records = [{**data, 'path': self.path} for data in self.metadata]
            metadata_list.extend(new_records)   

        for child in self.children:
            child.create_embeddings_metadata(metadata_list)
        
        return metadata_list


if __name__ == "__main__":
    # Example: Load the index.json and print the directory structure.
    tree_root = TreeNode.load_from_file("Repo_Index/repo_index.json")
    if tree_root:
        # Optionally set the base_path if needed, e.g.:
        # TreeNode.base_path = "repo_clone_dir"
        # tree_root.print_tree()  # Existing log output
        # print("\nDirectory Structure:\n")
        # tree_root.print_directory_structure()
        # for doc in tree_root.get_all_methods_and_tests():
        #     print(doc)
        #     print("\n", "*" * 50, "\n")

        # test_parent_child_connections(tree_root)
        metadatas = tree_root.create_embeddings_metadata()
        print(len(metadatas))
        print(metadatas[6])