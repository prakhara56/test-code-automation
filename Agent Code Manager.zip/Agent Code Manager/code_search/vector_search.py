# semantic_code_search/vector_search.py
import gzip
import os
import pickle
# import torch
import requests
import numpy as np
# from sentence_transformers import util#,SentenceTransformer
from sklearn.cluster import AgglomerativeClustering
import faiss
from loguru import logger
import time
# from .embed import do_embed

# def _search(query_embedding, corpus_embeddings, functions, k=5, file_extension=None):
#     # TODO: implement file extension filtering if desired.
#     cos_scores = util.cos_sim(query_embedding, corpus_embeddings)[0]
#     top_results = torch.topk(cos_scores, k=min(k, len(cos_scores)), sorted=True)
#     out = []
#     for score, idx in zip(top_results[0], top_results[1]):
#         out.append((score.item(), functions[idx]))
#     return out

def _load_faiss_index(embeddings: np.ndarray):
    d=embeddings.shape[1]
    index = faiss.IndexFlatL2(d)
    index.add(embeddings)
    return index

def _search_index(index:faiss.IndexFlatL2,query_embedding, functions, k=5):
    if query_embedding.ndim == 1:
        query_embedding = query_embedding.reshape(1, -1)
    
    scores, indices = index.search(query_embedding, k)
    # print(scores, indices)
    out = []
    for score, idx in zip(scores[0], indices[0]):
        out.append((float(score), functions[idx]))
    return out

def _query_embeddings(model, args, dataset):

    logger.info(f"Response initiated at {time.time()}")
    response = requests.post(
        f"{model}/embed",
        json={"sentences": [args['query_text']]}
    )
    # time.sleep(5)
    logger.info(f"Response received at {time.time()}")
    print("---"*50)

    if response.status_code != 200:
        raise Exception(f"Failed to get embedding from API: {response.text}")

    query_embedding = np.array(response.json()['embeddings'][0], dtype='float32')
    
    # results = _search(query_embedding, emb_data.get("embeddings"), functions, k=args.n_results, file_extension=args.file_extension)
    
    embeddings = np.array([data['embedding'] for data in dataset],dtype='float32')
    index = _load_faiss_index(embeddings)
    results = _search_index(index, query_embedding, dataset, k=args['n_results'])
    
    
    return results

def get_clusters(dataset, distance_threshold):
    embeddings = np.array(dataset.get('embeddings'))
    embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
    clustering_model = AgglomerativeClustering(
        n_clusters=None,
        distance_threshold=distance_threshold,
        compute_distances=True,
    )
    clustering_model.fit(embeddings)
    cluster_assignment = clustering_model.labels_
    cluster_distances = clustering_model.distances_
    cluster_children = clustering_model.children_

    clustered_functions = {}
    for idx, cluster_id in enumerate(cluster_assignment):
        clustered_functions.setdefault(cluster_id, []).append(dataset['functions'][idx])

    clusters = []
    for cluster_id, funcs in clustered_functions.items():
        if len(funcs) > 1:
            clusters.append({
                'cluster_id': cluster_id,
                'functions': funcs,
                'avg_distance': np.mean(cluster_distances)  # Simplified; adjust as needed.
            })
    return clusters

def search_query(args, model, dataset):
    results = _query_embeddings(model, args, dataset)
    # print("Search Results:")
    # for score, func in results:
    #     print(f"Score: {score:.3f} | File: {func.get('path', 'unknown')} | Lines: {func.get('lines', 'N/A')} | Node Type: {func.get('node_type', 'N/A')}")
    #     print(func.get("text", "")[:200], "...\n")
    return results

def cluster_query(args, model):
    # Load the combined dataset.
    from .hybrid_storage import hybrid_load
    dataset = hybrid_load(args)
    clusters = get_clusters(dataset, args['cluster_max_distance'])
    print("Clusters:")
    for cluster in clusters:
        print(f"Cluster {cluster['cluster_id']} (avg distance: {cluster['avg_distance']:.3f}):")
        for func in cluster['functions']:
            print(f"  {func.get('file', 'unknown')}:{func.get('start_line', 'N/A')}")
    return clusters

if __name__ == "__main__":
    import argparse
    from sentence_transformers import SentenceTransformer
    parser = argparse.ArgumentParser(description="Vector search and clustering for repository functions.")
    parser.add_argument("--path_to_repo", type=str, required=True, help="Path to the repository")
    parser.add_argument("--model_name_or_path", type=str, default="krlvi/sentence-t5-base-nlpl-code_search_net",
                        help="Embedding model name or path")
    parser.add_argument("--query_text", type=str, help="Query text for search")
    parser.add_argument("--n_results", type=int, default=5, help="Number of search results to return")
    parser.add_argument("--file_extension", type=str, default=None, help="Filter search by file extension")
    parser.add_argument("--cluster_max_distance", type=float, default=0.5, help="Max distance threshold for clustering")
    parser.add_argument("--mode", type=str, choices=["search", "cluster"], default="search", help="Operation mode")
    args = parser.parse_args()

    model = SentenceTransformer(args.model_name_or_path)
    if args.mode == "search":
        search_query(args, model)
    elif args.mode == "cluster":
        cluster_query(args, model)
