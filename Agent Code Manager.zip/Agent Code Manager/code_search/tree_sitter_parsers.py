# # semantic_code_search/tree_sitter_parsers.py
# import os
# from tree_sitter import Parser, Tree, Node
# from tree_sitter_languages import get_parser
# from loguru import logger
# from typing import Generator
# from textwrap import dedent


# # Map file extensions to Tree-sitter language names.
# EXTENSION_LANGUAGE = {
#     '.py': 'python',
#     '.js': 'javascript',
#     '.ts': 'typescript',
#     '.java': 'java',
#     # Add additional mappings as needed.
# }

# relevant_node_types = {
#     'function_definition',
#     'method_definition',
#     'class_definition',
#     'function_declaration',
#     'method_declaration',
#     'class_declaration',
#     'import_declaration',
#     'package_declaration',
#     'field_declaration'
# }

# def get_parser_for_file(file_path:str)->Parser:

#     # get the language name from the extension
#     ext = file_path[file_path.rfind('.'):]
#     lang = EXTENSION_LANGUAGE.get(ext,None)

#     if not lang:
#         logger.debug(f"No Tree-sitter parser available for extension: {ext}")
#         return None
    
#     parser = get_parser(lang)
#     return parser

# def _traverse_tree(tree: Node)->Generator[Node, None, None]:
#     cursor = tree.walk()
#     reached_root = False
#     while reached_root is False:
#         yield cursor.node
#         if cursor.goto_first_child():
#             continue
#         if cursor.goto_next_sibling():
#             continue
#         retracing = True
#         while retracing:
#             if not cursor.goto_parent():
#                 retracing = False
#                 reached_root = True
#             if cursor.goto_next_sibling():
#                 retracing = False


# def _extract_functions(nodes, file_content, relevant_node_types):
#     out = []
#     for n in nodes:
#         if n.type in relevant_node_types:
#             node_text = dedent('\n'.join(file_content.split('\n')[
#                                n.start_point[0]:n.end_point[0]+1]))
#             out.append(
#                 {'lines': (n.start_point[0],n.end_point[0]), 'node_type':n.type, 'text': node_text}
#             )
#     return out


# def parse_file(file_path, file_extensions):
#     """
#     Generic parser using Tree-sitter. Depending on the file extension,
#     extract functions, classes, or methods.
#     """
#     ext = file_path[file_path.rfind('.'):]
#     if ext not in file_extensions:
#         logger.debug(f"File extension {ext} not supported for parsing.")
#         return []
#     parser = get_parser_for_file(file_path)
#     if not parser:
#         return []
#     try:
#         with open(file_path, 'r') as f:
#             code = f.read()
#     except Exception as e:
#         logger.error(f"Error reading {file_path}: {e}")
#         return []

#     # Making parser tree
#     tree = parser.parse(bytes(code, 'utf8'))
    
#     # Getting all nodes of tree in DFS
#     all_nodes = list(_traverse_tree(tree.root_node))
#     result = _extract_functions(all_nodes, code, relevant_node_types)
    
#     return result


# # semantic_code_search/tree_sitter_parsers.py

# import os
# from tree_sitter import Language, Parser, Node
# from loguru import logger
# from typing import Generator, Optional, List, Dict

# # Import individual Tree-sitter grammar packages.
# # Each grammar package exposes a function returning a language pointer.
# import tree_sitter_python as tspython        # Python grammar
# import tree_sitter_javascript as tsjavascript  # JavaScript grammar
# import tree_sitter_typescript as tstypescript  # TypeScript & TSX grammars
# import tree_sitter_java as tsjava            # Java grammar

# # Map file extensions to language keys.
# EXTENSION_LANGUAGE: Dict[str, str] = {
#     '.py': 'python',
#     '.js': 'javascript',
#     '.ts': 'typescript',
#     '.java': 'java',
#     # Add other extensions as needed.
# }

# # Preload Language objects for each supported language.
# # Notice: for TypeScript, we call .typescript() instead of .language()
# LANGUAGE_LIBRARY: Dict[str, Language] = {
#     'python': Language(tspython.language()),            # :contentReference[oaicite:2]{index=2}
#     'javascript': Language(tsjavascript.language()),     # :contentReference[oaicite:3]{index=3}
#     'typescript': Language(tstypescript.language_typescript()),   # :contentReference[oaicite:4]{index=4}
#     'java': Language(tsjava.language()),                 # :contentReference[oaicite:5]{index=5}
# }

# # Node types to extract (functions, classes, imports, etc.).
# RELEVANT_NODE_TYPES = {
#     'function_definition',
#     'method_definition',
#     'class_definition',
#     'function_declaration',
#     'method_declaration',
#     'class_declaration',
#     'import_declaration',
#     'package_declaration',
#     'field_declaration'
# }

# def get_parser_for_file(file_path: str) -> Optional[Parser]:
#     """
#     Return a Tree-sitter Parser configured for the language corresponding to file_path’s extension.
#     If unsupported, return None.
#     """
#     _, ext = os.path.splitext(file_path)
#     lang_key = EXTENSION_LANGUAGE.get(ext)
#     if not lang_key:
#         logger.debug(f"No Tree-sitter parser available for extension: {ext}")
#         return None

#     language = LANGUAGE_LIBRARY.get(lang_key)
#     if not language:
#         logger.debug(f"Language '{lang_key}' not found in LANGUAGE_LIBRARY.")
#         return None

#     try:
#         # v0.23+: Parser takes a Language object in its constructor
#         parser = Parser(language)   # :contentReference[oaicite:6]{index=6}
#         return parser
#     except Exception as e:
#         logger.error(f"Failed to create Parser for language '{lang_key}': {e}")
#         return None

# def _traverse_tree(root: Node) -> Generator[Node, None, None]:
#     """
#     Depth-first traversal over the syntax tree nodes, yielding each Node.
#     """
#     cursor = root.walk()
#     reached_root = False
#     while not reached_root:
#         yield cursor.node
#         if cursor.goto_first_child():
#             continue
#         if cursor.goto_next_sibling():
#             continue
#         retracing = True
#         while retracing:
#             if not cursor.goto_parent():
#                 retracing = False
#                 reached_root = True
#             if cursor.goto_next_sibling():
#                 retracing = False

# def _extract_functions(
#     nodes: List[Node],
#     file_content: str,
#     relevant_node_types: set
# ) -> List[Dict]:
#     """
#     From a list of Tree-sitter Nodes, extract those whose type is in relevant_node_types.
#     Return a list of dicts, each containing:
#       - 'lines': (start_row, end_row)
#       - 'node_type'
#       - 'text': code snippet for that node
#     """
#     results: List[Dict] = []
#     lines = file_content.split('\n')
#     for node in nodes:
#         if node.type in relevant_node_types:
#             start_row, _ = node.start_point
#             end_row, _ = node.end_point
#             node_text = '\n'.join(lines[start_row : end_row + 1])
#             results.append({
#                 'lines': (start_row, end_row),
#                 'node_type': node.type,
#                 'text': node_text
#             })
#     return results

# def parse_file(file_path: str, file_extensions: List[str]) -> List[Dict]:
#     """
#     Generic parser entry-point. If file_path’s extension is in file_extensions,
#     parse the file with Tree-sitter and return relevant nodes.
#     """
#     _, ext = os.path.splitext(file_path)
#     if ext not in file_extensions:
#         logger.debug(f"File extension {ext} not supported for parsing.")
#         return []

#     parser = get_parser_for_file(file_path)
#     if not parser:
#         return []

#     try:
#         with open(file_path, 'r', encoding='utf-8') as f:
#             code = f.read()
#     except Exception as e:
#         logger.error(f"Error reading {file_path}: {e}")
#         return []

#     # Parse the source code into a Tree
#     try:
#         tree = parser.parse(code.encode('utf8'))
#     except Exception as e:
#         logger.error(f"Tree-sitter failed to parse {file_path}: {e}")
#         return []

#     all_nodes = list(_traverse_tree(tree.root_node))  # :contentReference[oaicite:7]{index=7}
#     result = _extract_functions(all_nodes, code, RELEVANT_NODE_TYPES)
#     return result


# semantic_code_search/tree_sitter_parsers.py

import os
from tree_sitter import Language, Parser, Node
from loguru import logger
from typing import Generator, Optional, List, Dict

# Import individual Tree-sitter grammar packages
import tree_sitter_python as tspython
import tree_sitter_javascript as tsjavascript
import tree_sitter_typescript as tstypescript
import tree_sitter_java as tsjava
import tree_sitter_xml as tsxml  # <-- XML grammar package

# Map file extensions to “language keys”
EXTENSION_LANGUAGE: Dict[str, str] = {
    '.py': 'python',
    '.js': 'javascript',
    '.ts': 'typescript',
    '.java': 'java',
    '.xml': 'xml',           # <-- We now claim “.xml” is parseable
}

# Preload Language objects
LANGUAGE_LIBRARY: Dict[str, Language] = {
    'python': Language(tspython.language()),
    'javascript': Language(tsjavascript.language()),
    'typescript': Language(tstypescript.language_typescript()),
    'java': Language(tsjava.language()),
    'xml': Language(tsxml.language_xml()),    # <-- Load XML grammar
}

# Node types to extract for code files
RELEVANT_NODE_TYPES = {
    'function_definition', 'method_definition', 'class_definition',
    'function_declaration', 'method_declaration', 'class_declaration',
    'import_declaration', 'package_declaration', 'field_declaration'
}

# Node types to extract from pom.xml specifically
POM_NODE_TYPES = {
    'element',   # We'll look for <dependency> child elements inside  
}

def get_parser_for_file(file_path: str) -> Optional[Parser]:
    """
    Instantiate a Parser for the language matching file_path’s extension.
    """
    _, ext = os.path.splitext(file_path)
    lang_key = EXTENSION_LANGUAGE.get(ext)
    if not lang_key:
        logger.debug(f"No Tree-sitter parser available for extension: {ext}")
        return None

    language = LANGUAGE_LIBRARY.get(lang_key)
    if not language:
        logger.debug(f"Language '{lang_key}' not loaded.")
        return None

    try:
        return Parser(language)
    except Exception as e:
        logger.error(f"Failed to create Parser for '{lang_key}': {e}")
        return None

def _traverse_tree(root: Node) -> Generator[Node, None, None]:
    """
    Depth-first traversal over the syntax tree nodes.
    """
    cursor = root.walk()
    reached_root = False
    while not reached_root:
        yield cursor.node
        if cursor.goto_first_child():
            continue
        if cursor.goto_next_sibling():
            continue
        retracing = True
        while retracing:
            if not cursor.goto_parent():
                retracing = False
                reached_root = True
            if cursor.goto_next_sibling():
                retracing = False

def _extract_code_nodes(
    nodes: List[Node],
    file_content: str,
    relevant_node_types: set
) -> List[Dict]:
    """
    Extract functions/classes/imports/etc. from code‐oriented AST nodes.
    """
    results: List[Dict] = []
    lines = file_content.split('\n')
    for node in nodes:
        if node.type in relevant_node_types:
            start_row, _ = node.start_point
            end_row, _ = node.end_point
            snippet = '\n'.join(lines[start_row : end_row + 1])
            results.append({
                'lines': (start_row, end_row),
                'node_type': node.type,
                'text': snippet
            })
    return results


def _extract_pom_dependencies(tree: Node, source: str) -> List[Dict[str, str]]:
    """
    Specifically extract <dependency> blocks from a pom.xml's CST.
    Each <dependency> element is an 'element' node whose first named child
    (inside its STag) is a Name node with text 'dependency'. For each such
    <dependency>, extract groupId, artifactId, and version by inspecting
    its nested <element> children for those tag names.
    """
    dependencies: List[Dict[str, str]] = []
    lines = source.split('\n')

    for node in _traverse_tree(tree.root_node):
        # Identify top-level <dependency> elements
        if node.type == 'element':
            named_children = node.named_children
            if not named_children:
                continue

            start_tag = named_children[0]
            if start_tag.type != 'STag':
                continue

            # The tag’s name is in start_tag.named_children[0]
            if not start_tag.named_children:
                continue
            name_node = start_tag.named_children[0]
            tag_text = name_node.text.decode('utf8').strip()
            if tag_text != 'dependency':
                continue

            # At this point, 'node' represents a <dependency> element.
            dep_info: Dict[str, str] = {}

            # Iterate each nested <element> to locate groupId, artifactId, version
            for child in node.named_children:
                if child.type == 'element':
                    c_named = child.named_children
                    if not c_named:
                        continue
                    c_start_tag = c_named[0]
                    if c_start_tag.type != 'STag' or not c_start_tag.named_children:
                        continue

                    c_name_node = c_start_tag.named_children[0]
                    child_tag = c_name_node.text.decode('utf8').strip()

                    if child_tag in ('groupId', 'artifactId', 'version'):
                        # Extract the inner text from <groupId>…</groupId>
                        for grandchild in child.named_children:
                            if grandchild.type == 'CharData':
                                value = grandchild.text.decode('utf8').strip()
                                dep_info[child_tag] = value
                                break

            # Only add if all three mandatory fields are present
            if all(k in dep_info for k in ('groupId', 'artifactId', 'version')):
                dependencies.append(dep_info)

    return dependencies

def parse_file(file_path: str, file_extensions: List[str]) -> List[Dict]:
    """
    Generic parser entry-point. Supports:
      - .py, .js, .ts, .java → code-oriented node extraction
      - pom.xml specifically → dependency extraction
    """
    _, ext = os.path.splitext(file_path)
    base = os.path.basename(file_path)

    # If this is an .xml file that isn’t literally “pom.xml,” skip it:
    if ext == '.xml' and base.lower() != 'pom.xml':
        logger.debug(f"Skipping non-pom XML file: {file_path}")
        return []

    if ext not in file_extensions:
        logger.debug(f"File extension {ext} not supported.")
        return []

    parser = get_parser_for_file(file_path)
    if not parser:
        return []

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
            print(f"Parsing file: \n{code}")
    except Exception as e:
        logger.error(f"Error reading {file_path}: {e}")
        return []

    try:
        tree = parser.parse(code.encode('utf8'))
    except Exception as e:
        logger.error(f"Tree-sitter parse error for {file_path}: {e}")
        return []

    all_nodes = list(_traverse_tree(tree.root_node))

    # If this is exactly “pom.xml,” run our POM-specific extractor:
    if ext == '.xml' and base.lower() == 'pom.xml':
        return _extract_pom_dependencies(tree, code)

    # Otherwise it’s a code file; extract functions/classes/imports, etc.
    return _extract_code_nodes(all_nodes, code, RELEVANT_NODE_TYPES)
