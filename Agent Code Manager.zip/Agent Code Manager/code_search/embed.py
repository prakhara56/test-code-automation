# semantic_code_search/embed.py
import os
import sys
import gzip
import pickle
from tqdm import tqdm
import numpy as np
from sentence_transformers import SentenceTransformer
from loguru import logger
import requests
import time


def do_embed(index_path: str, model: SentenceTransformer):
    """
    Clone/index the repository (if not already done) and compute embeddings for each function.
    Returns a dataset with keys: 'functions', 'embeddings', 'model_name'
    """
    # Assume the repo is already cloned and indexed.
    # Here we load the index (JSON metadata) using RepoIndexer.
    from .tree_node import TreeNode
    if not os.path.isfile(index_path):
        print(f"Index not found in {index_path}. Please index the repository first.")
        sys.exit(1)
    
    # For simplicity, load JSON metadata (list of function dicts)
    tree_node = TreeNode.load_from_file(index_path)
    functions = tree_node.create_embeddings_metadata()

    # Create embeddings for each function's code snippet.
    texts = [func.get("text", "") for func in functions]
    logger.debug(f"Embedding {len(texts)} functions...")
    # corpus_embeddings = model.encode(texts, convert_to_tensor=False, show_progress_bar=True)
    logger.info(f"Embedding request initiated at {time.time()}")

    response = requests.post(
        f"{model}/embed",
        json={"sentences": texts}
    )

    if response.status_code == 200:
        corpus_embeddings = response.json().get("embeddings", [])
    else:
        logger.error(f"Embedding request failed with status {response.status_code}: {response.text}")
        corpus_embeddings = None


    dataset = [{**func,'embedding':corpus_embeddings[i],'index_used':index_path} for i,func in enumerate(functions)]

    # Save the embeddings using hybrid_storage if desired.
    embeddings_path = os.path.join(os.path.dirname(index_path), f"{os.path.splitext(os.path.basename(index_path))[0]}.embeddings")
    with gzip.open(embeddings_path, "wb") as f:
        pickle.dump(dataset, f)
    print(f"Saved embeddings to {embeddings_path}")
    return dataset

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generate embeddings for repository functions.")
    parser.add_argument("--path_to_repo", type=str, required=True, help="Path to the repository")
    parser.add_argument("--model_name_or_path", type=str, default="krlvi/sentence-t5-base-nlpl-code_search_net",
                        help="Hugging Face model for code embeddings")
    parser.add_argument("--batch_size", type=int, default=32, help="Batch size for embedding")
    args = parser.parse_args()

    model = SentenceTransformer(args['path_to_index'])
    do_embed(args, model)
