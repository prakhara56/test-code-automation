# semantic_code_search/utils.py
import stat
import os, subprocess
from loguru import logger

def remove_readonly(func, path, exc_info):
    os.chmod(path, stat.S_IWRITE)
    func(path)

def get_default_branch(folder_path):
    try:
        result = subprocess.run(
            ["git", "-C", folder_path, "symbolic-ref", "refs/remotes/origin/HEAD"],
            capture_output=True, text=True, check=True
        )
        ref = result.stdout.strip()
        return ref.split('/')[-1]
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to get default branch for {folder_path}: {e}")
        return None
