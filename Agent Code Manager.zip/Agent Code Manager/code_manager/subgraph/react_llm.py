from typing import List, Annotated
from typing_extensions import TypedDict

import os
import json
import asyncio
from dotenv import load_dotenv

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_community.adapters.openai import convert_message_to_dict
from langchain_core.messages import AIMessage, HumanMessage, BaseMessage
from langchain_core.runnables import RunnableSerializable
from openai import AzureOpenAI

from langgraph.graph import END, StateGraph, START
from langgraph.graph.message import add_messages

from code_manager.llm import llm
from code_manager.prompts import page_function_prompt
from code_manager.tools import search_code, project_structure

from loguru import logger

# Load environment variables
load_dotenv()

# Initialize Azure OpenAI client
model = AzureOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
)

def my_chat_bot(messages: List[dict]) -> dict:
    # logger.debug(f"ChatBot received messages: {messages}")
    system_message = {
        "role": "system",
        "content": "You are a qa engineer expert who can analyse inputs and provide automation scripts or answers according to what is asked in input. Always respond in JSON format as specified in initial message.",
    }
    messages = [system_message] + messages
    completion = model.chat.completions.create(
        messages=messages, model=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"]
    )
    response = completion.choices[0].message.model_dump()
    logger.debug(f"ChatBot response: {response}")
    return response

def set_simulated_user(state):

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", state['system_prompt_template']),
            MessagesPlaceholder(variable_name="messages"),
        ]
    )

    simulated_user = prompt | llm.bind_tools([search_code,project_structure])

    return {'simulated_user':simulated_user}

def chat_bot_node(state):
    logger.info("chat_bot_node invoked")
    messages = state["messages"]
    messages = [convert_message_to_dict(m) for m in messages]
    chat_bot_response = my_chat_bot(messages)
    # logger.debug(f"chat_bot_node returning: {chat_bot_response['content']}")
    return {"messages": [AIMessage(content=chat_bot_response["content"])]}

def _swap_roles(messages: List[BaseMessage]):
    new_messages = []
    for m in messages:
        if isinstance(m, AIMessage):
            new_messages.append(HumanMessage(content=m.content))
        else:
            new_messages.append(AIMessage(content=m.content))
    return new_messages

def simulated_user_node(state):
    logger.info("simulated_user_node invoked")
    messages = state["messages"]
    new_messages = _swap_roles(messages)
    response = state['simulated_user'].invoke({"messages": new_messages})
    logger.debug(f"simulated_user_node response: {response.content}")
    return {"messages": [HumanMessage(content=response.content)]}

def should_continue(state):
    messages = state["messages"]
    if len(messages) > 6:
        logger.info("Stopping: Max message limit reached.")
        return "end"
    # elif "FINISHED" == messages[-1].content.upper():
    #     logger.info("Stopping: Conversation finished.")
    #     return "end"
    elif "FINISHED" in messages[-1].content.upper():
        logger.info("Stopping: Conversation finished.")
        return "end"
    else:
        return "continue"

class State(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
    simulated_user: RunnableSerializable
    system_prompt_template: str

def build_simulation_graph():
    graph_builder = StateGraph(State)
    graph_builder.add_node("set_simulated_user", set_simulated_user)
    graph_builder.add_node("user", simulated_user_node)
    graph_builder.add_node("chat_bot", chat_bot_node)

    graph_builder.add_edge("set_simulated_user", "chat_bot")
    graph_builder.add_edge("chat_bot", "user")
    graph_builder.add_conditional_edges(
        "user",
        should_continue,
        {
            "end": END,
            "continue": "chat_bot",
        },
    )
    graph_builder.add_edge(START, "set_simulated_user")
    simulation = graph_builder.compile(checkpointer=False)


    # Generate and save the graph visualization
    png_bytes = simulation.get_graph().draw_mermaid_png()
    os.makedirs("static", exist_ok=True)
    with open('static/llm_converse_workflow.png', 'wb') as file:
        file.write(png_bytes)
    logger.info("Saved workflow graph to static/llm_converse_workflow.png")

    return simulation


async def react_agent(initial_message: str, system_prompt_template: str):
    logger.info("React agent invoked")
    simulation = build_simulation_graph()
    simulation_result = await simulation.ainvoke({"messages": [initial_message], "system_prompt_template":system_prompt_template})
    # logger.debug(f"Simulation result: {simulation_result}")
    return simulation_result

