from typing import List, Annotated, Tuple, Any
from typing_extensions import TypedDict
from pprint import pprint
import os
import json
import asyncio
from dotenv import load_dotenv
import openai

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_community.adapters.openai import convert_message_to_dict
from langchain_core.messages import AIMessage, HumanMessage, BaseMessage
from langchain_core.messages import ToolMessage

from langchain_core.runnables import RunnableSerializable, Runnable
from openai import AzureOpenAI

from langgraph.graph import END, StateGraph, START
from langgraph.graph.state import CompiledStateGraph
from langgraph.graph.message import add_messages
from langgraph.types import RetryPolicy

from code_manager.llm import llm
from code_manager.prompts import page_function_prompt
# from code_manager.tools import search_code, project_structure, file_reader
from code_manager.tools import (
    make_search_code_tool,
    make_project_structure_tool,
    make_repo_file_read_tool
)
from code_manager.utils import openai_retry_on

from loguru import logger

# Load environment variables
load_dotenv()

# Initialize Azure OpenAI client
model = AzureOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
)


class BasicToolNode:
    """A node that runs the tools requested in the last AIMessage."""

    def __init__(self, tools: list) -> None:
        self.tools_by_name = {tool.name: tool for tool in tools}

    def __call__(self, inputs: dict):
        if messages := inputs.get("messages", []):
            message = messages[-1]
        else:
            raise ValueError("No message found in input")
        outputs = []
        for tool_call in message.tool_calls:
            tool_result = self.tools_by_name[tool_call["name"]].invoke(
                tool_call["args"]
            )
            outputs.append(
                ToolMessage(
                    content=json.dumps(tool_result),
                    name=tool_call["name"],
                    tool_call_id=tool_call["id"],
                )
            )
        if len(outputs)>0:
            logger.debug(f"Tool Call for tool {tool_call['name']} Successful")
        else:
            logger.debug("Tool calls for the last message were not successful or no tool calls were made.")
        return {"messages": outputs}
    
    async def _invoke_tool_async(self, name: str, args: dict) -> Any:
        """Run .invoke() in a thread so it doesn’t block the event loop."""
        loop = asyncio.get_event_loop()
        tool = self.tools_by_name[name]
        return await loop.run_in_executor(None, lambda: tool.invoke(args))

    async def acall(self, inputs: dict) -> dict:
        """Async variant that invokes all tool calls in parallel."""
        if messages := inputs.get("messages", []):
            message = messages[-1]
        else:
            raise ValueError("No message found in input")

        # schedule all tool invocations concurrently
        tasks = []
        for call in message.tool_calls:
            tasks.append(
                asyncio.create_task(
                    self._invoke_tool_async(call["name"], call["args"])
                )
            )

        # wait for all to finish
        results = await asyncio.gather(*tasks, return_exceptions=True)

        outputs = []
        for call, result in zip(message.tool_calls, results):
            if isinstance(result, Exception):
                logger.error(f"Tool {call['name']} failed: {result}")
                continue

            outputs.append(
                ToolMessage(
                    content=json.dumps(result),
                    name=call["name"],
                    tool_call_id=call["id"],
                )
            )

        if outputs:
            logger.debug(f"Async tool calls completed successfully")
        else:
            logger.debug("No successful async tool calls made")

        return {"messages": outputs}

def my_chat_bot(messages: List[dict]) -> dict:
    logger.debug(f"ChatBot received messages: {messages}")
    system_message = {
        "role": "system",
        "content": "You are a qa engineer expert who can analyse inputs and provide automation scripts or answers according to what is asked in input. Always respond in JSON format as specified in initial message.",
    }
    messages = [system_message] + messages
    completion = model.chat.completions.create(
        messages=messages, model=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"]
    )
    response = completion.choices[0].message.model_dump()



    logger.debug(f"ChatBot response: {response}")
    return response

def set_simulated_user(state):

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", state['system_prompt_template']),
            MessagesPlaceholder(variable_name="messages"),
        ]
    )

    simulated_user = prompt | llm.with_retry(
                            retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                            stop_after_attempt=5,
                            wait_exponential_jitter=True
                        )

    return {'simulated_user':simulated_user}

def chat_bot_node(state):
    # logger.info("chat_bot_node invoked")
    # messages = state["messages"]
    # messages = [convert_message_to_dict(m) for m in messages]
    # chat_bot_response = my_chat_bot(messages)
    # # logger.debug(f"chat_bot_node returning: {chat_bot_response['content']}")
    # return {"messages": [AIMessage(content=chat_bot_response["content"])]}
    response = state["llm_with_tools"].invoke(state["messages"])
    logger.debug(f"ChatBot response:")
    pprint(response.content)
    return {"messages": [response]}

def _swap_roles(messages: List[BaseMessage]):
    new_messages = []
    for m in messages:
        if isinstance(m, AIMessage):
            new_messages.append(HumanMessage(content=m.content))
        else:
            new_messages.append(AIMessage(content=m.content))
    return new_messages

def simulated_user_node(state):
    logger.info("simulated_user_node invoked")
    messages = state["messages"]
    new_messages = _swap_roles(messages)
    response = state['simulated_user'].invoke({"messages": new_messages})
    logger.debug(f"simulated_user_node response:")
    pprint(response.content)
    return {"messages": [HumanMessage(content=response.content)]}

def should_continue(state):
    messages = state["messages"]
    if isinstance(state, list):
        ai_message = state[-1]
    elif messages := state.get("messages", []):
        ai_message = messages[-1]
    else:
        raise ValueError(f"No messages found in input state to tool_edge: {state}")
    if hasattr(ai_message, "tool_calls") and len(ai_message.tool_calls) > 0:
        return "tools"

    # if len(messages) > 6:
    #     logger.info("Stopping: Max message limit reached.")
    #     return "end"
    # elif "FINISHED" == messages[-1].content.upper():
    #     logger.info("Stopping: Conversation finished.")
    #     return "end"
    if "FINISHED" in messages[-1].content.upper():
        logger.info("Stopping: Conversation finished.")
        return "end"
    else:
        return "continue"

class State(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
    simulated_user: RunnableSerializable
    system_prompt_template: str
    llm_with_tools: Runnable

def build_simulation_graph(clone_dir: str = None, repo_name: str = None, model_endpoint: str = "http://127.0.0.1:8000") -> Tuple[CompiledStateGraph, Runnable]:


    # Builid the tools
    search_code = make_search_code_tool(clone_dir, repo_name, model_endpoint)
    project_structure = make_project_structure_tool(clone_dir, repo_name)
    file_reader = make_repo_file_read_tool(clone_dir, repo_name)
    tools = [search_code, project_structure, file_reader]

    graph_builder = StateGraph(State)
    graph_builder.add_node("set_simulated_user", set_simulated_user)
    graph_builder.add_node("user", simulated_user_node)
    graph_builder.add_node("chat_bot", chat_bot_node)
    graph_builder.add_node("tools", BasicToolNode(tools))

    graph_builder.add_edge("set_simulated_user", "chat_bot")
    graph_builder.add_conditional_edges(
        "chat_bot",
        should_continue,
        {
            "end": END,
            "continue": "user",
            "tools": "tools"
        },
    )
    # graph_builder.add_edge("chat_bot", "user")
    graph_builder.add_conditional_edges(
        "user",
        should_continue,
        {
            "end": END,
            "continue": "chat_bot",
            "tools": "tools"
        },
    )
    
    graph_builder.add_edge(START, "set_simulated_user")
    graph_builder.add_edge("tools", "chat_bot")
    simulation = graph_builder.compile(checkpointer=False)


    # Generate and save the graph visualization
    # png_bytes = simulation.get_graph().draw_mermaid_png()
    # os.makedirs("static", exist_ok=True)
    # with open('static/llm_converse_workflow.png', 'wb') as file:
    #     file.write(png_bytes)
    # logger.info("Saved workflow graph to static/llm_converse_workflow.png")

    return simulation, llm.bind_tools(tools).with_retry(
                            retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                            stop_after_attempt=7,
                            wait_exponential_jitter=True
                        )


async def react_agent(initial_message: str, system_prompt_template: str, recursion_limit:int = 25, clone_dir:str = None, repo_name:str = None) -> dict:
    logger.info("React agent invoked")
    simulation, llm_with_tools = build_simulation_graph(clone_dir, repo_name)
    simulation_result = await simulation.ainvoke(
        {
            "messages": [initial_message], 
            "system_prompt_template":system_prompt_template,
            "llm_with_tools": llm_with_tools,
        },
        {
            "recursion_limit": recursion_limit
        }
    )
    # logger.debug(f"Simulation result: {simulation_result}")
    return simulation_result

