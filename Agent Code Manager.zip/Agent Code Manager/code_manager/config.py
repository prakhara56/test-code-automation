from langgraph.graph import END,StateGraph
from langgraph.pregel import RetryPolicy
# from Story_Creation.agents import *
from code_manager.utils import openai_retry_on
from code_manager.models import AgentState
from typing import Dict, List,Tuple, Any, Literal

from code_manager.nodes import *


def check_if_all_gherkin_steps_are_matched(state:AgentState)->Literal['conitune','end']:
    if state['feature_files'] is None:
        return "continue"        
        
    for file in state['feature_files']:
        if len(file['gherkin_steps_which_do_not_have_step_function']) > 0:
            return "continue"
    
    return "end"

NODES: Dict = {
    "plan_steps":plan_steps,
    "query_steps":query_steps,
    "find_relevant_queries":find_relevant_queries,
    "generate_automation_files":generate_automation_files,
    "feature_file_generation":feature_file_generation,
    "match_feature_file":match_feature_file,
    "page_function_generation":page_function_generation,
    "step_function_generation":step_function_generation,
    "check_codebase_for_plan_summary":check_codebase_for_plan_summary,
}

RETRY_NODES: Dict[str,Tuple[Any,RetryPolicy]] = {
    # "": (breakdown_epics,RetryPolicy(retry_on=))
}

ENTRY_POINT: str = "plan_steps"

EDGES: List[Tuple] = [
    ("plan_steps","check_codebase_for_plan_summary"),
    # ("plan_steps", "query_steps"),
    # ("query_steps","find_relevant_queries"),
    # ("find_relevant_queries","generate_automation_files"),
    ("check_codebase_for_plan_summary","generate_automation_files"),
    ("generate_automation_files", "feature_file_generation"),
    # ("feature_file_generation","match_feature_file"),
    # ("match_feature_file", "page_function_generation"),
    ("page_function_generation", "step_function_generation"),
    ("step_function_generation", END),
]

CONDITIONAL_EDGES: List[Tuple] = [
    # ("match_feature_file",check_if_all_gherkin_steps_are_matched,{"continue":"page_function_generation", "end":END})
    ("feature_file_generation",check_if_all_gherkin_steps_are_matched,{"continue":"page_function_generation", "end":END})
]