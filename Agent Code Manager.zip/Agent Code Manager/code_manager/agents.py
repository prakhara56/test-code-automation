from typing import Any, Dict, List
import json
import asyncio
import openai

from loguru import logger
from langgraph.types import Send
from langgraph.graph import StateGraph, START, END
from langchain_core.runnables import RunnableSerializable
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_core.prompts import HumanMessagePromptTemplate
from code_manager.utils import (
    chunker,
    merge_partial_requirements,
    process_chunk,
    validate_epics
)
from code_manager.llm import llm
from code_manager.models import (
    AgentState,
    RequirementsOutput,
    EpicResult,
    UserStoryDescription,
    AcceptanceCriteria,
    Dependencies,
    Prioritization,
    Sprints
)
from code_manager.prompts import requirement_prompt

# -------------------------------
# Define our overall state.
# -------------------------------

# -------------------------------
# NODE 1: Set extraction config
# -------------------------------
def extract_req_config(state: AgentState, config: Dict[str, Any]) -> Dict[str, bool]:
    logger.debug("EXTRACT_REQ_CONFIG: Setting use_rag flag.")
    return {"req_rag": config["configurable"].get("use_rag", False)}

# -------------------------------
# NODE 2: Split Document into Chunks
# -------------------------------
def split_document(state: AgentState, config: Dict[str, Any]) -> Dict[str, List[str]]:
    logger.debug("SPLIT_DOCUMENT: Splitting requirement document into chunks.")
    requirement_doc = state["requirement_doc"]
    text_splitter = config["configurable"].get("text_splitter", "semantic")
    operation = config["configurable"].get("operation", "split_text")
    
    if text_splitter.lower() == "semantic":
        chunks = chunker(requirement_doc, text_splitter=text_splitter, operation=operation)
    elif text_splitter.lower() == "recursive":
        chunks = chunker(requirement_doc,
                         text_splitter=text_splitter,
                         chunk_size=len(requirement_doc) // 7,
                         chunk_overlap=200,
                         operation=operation)
    else:
        chunks = [requirement_doc]
    
    logger.info(f"SPLIT_DOCUMENT: Document split into {len(chunks)} chunks.")
    return {"chunks": chunks}

# -------------------------------
# MAPPING FUNCTION: Create Sends for Each Chunk
# -------------------------------
def map_chunks(state: AgentState) -> List[Send]:
    # For each chunk, send both the index and the chunk itself to the processing node.
    return [Send("process_chunk_node", {"i": i, "chunk": chunk}) for i, chunk in enumerate(state["chunks"])]

# -------------------------------
# NODE 3: Process a Single Chunk (Mapped Node)
# -------------------------------
async def process_chunk_node(state: Dict[str, Any]) -> Dict[str, List[Dict[str, str]]]:
    logger.debug("PROCESS_CHUNK_NODE: Processing a single chunk.")
    i = state.get("i")
    chunk = state.get("chunk")
    # Build the requirement chain with retry behavior.
    requirement_chain = requirement_prompt | llm.with_structured_output(schema=RequirementsOutput)\
                                              .with_retry(retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                                                          stop_after_attempt=5, wait_exponential_jitter=True)
    partial_requirements = await process_chunk(i, chunk, requirement_chain)
    return {"partial_requirements": partial_requirements}

# -------------------------------
# NODE 4: Merge Partial Requirements (Reduce Node)
# -------------------------------
def merge_requirements(state: AgentState, mapped_results: List[Dict[str, List[Dict[str, str]]]]) -> Dict[str, List[Dict[str, Any]]]:
    logger.debug("MERGE_REQUIREMENTS: Merging partial requirements from all chunks.")
    # Collect partial requirements from each mapped node.
    partials = [res["partial_requirements"] for res in mapped_results]
    requirements = merge_partial_requirements(partials)
    logger.debug(f"MERGE_REQUIREMENTS: Total unique requirements: {len(requirements)}")
    return {"requirements": requirements}

# -------------------------------
# NODE 5: Breakdown Epics
# -------------------------------
async def breakdown_epics(state: AgentState, config: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    logger.debug("BREAKDOWN_EPICS: Breaking down requirements into epics.")
    requirements = state['requirements']
    requirements_text = "\n".join([
        f"- id {req['id']}: {req['actor']} needs to {req['action']} (Constraint: {req.get('constraint', 'None')})"
        for req in requirements
    ])
    epic_breakdown_llm = llm.with_structured_output(schema=EpicResult)\
                              .with_retry(retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                                          stop_after_attempt=5, wait_exponential_jitter=True)
    base_prompt = [
        SystemMessage("You are an expert product manager organizing requirements into epics.\n"),
        HumanMessagePromptTemplate(),"The requirements are:\n"
        f"{requirements_text}\n\n"
        "Group these into high-level themes (epics). For each epic, provide a name and list which requirements (by their ids) fall under it. "
        "Ensure every requirement is assigned to an epic. "
        "Output JSON as an array with key `epics` where each object has 'epic_name' and 'requirements'."
    ]
    prompt = base_prompt
    retries = 0
    max_retries = config["configurable"].get("max_retries_epics", 5)
    while retries < max_retries:
        response = await epic_breakdown_llm.ainvoke(prompt)
        epics = json.loads(response.model_dump_json(indent=4))['epics']
        try:
            # Assume validate_epics raises an error if validation fails.
            validate_epics(epics, requirements)
            logger.success("BREAKDOWN_EPICS: Epics validation successful.")
            return {"epics": epics}
        except Exception as e:
            error_message = str(e)
            prompt = (
                base_prompt +
                "\n\nThe output did not meet the requirements because: " +
                error_message +
                "\nPlease revise the output so that each requirement id is valid and all appear exactly once." +
                f"\nGenerated Output: {response}"
            )
            retries += 1
    raise RuntimeError("BREAKDOWN_EPICS: Max retries reached. Unable to generate valid epics.")

# -------------------------------
# NODE 6: Assign Epics to Requirements
# -------------------------------
def assign_epics(state: AgentState) -> Dict[str, List[Dict[str, Any]]]:
    logger.debug("ASSIGN_EPICS: Assigning epics to each requirement.")
    requirements = state['requirements']
    epics = state['epics']
    for epic in epics:
        for req_id in epic.get("requirements", []):
            # Ensure each requirement has an 'epic' list.
            if "epic" not in requirements[req_id - 1] or not isinstance(requirements[req_id - 1]["epic"], list):
                requirements[req_id - 1]["epic"] = []
            requirements[req_id - 1]["epic"].append(epic.get("epic_name"))
    return {"requirements": requirements}

# -------------------------------
# MAPPING FUNCTION: Send Each Requirement for Story Generation
# -------------------------------
def map_requirements(state: AgentState) -> List[Send]:
    return [Send("generate_story", {"requirement": req}) for req in state["requirements"]]

# -------------------------------
# NODE 7: Generate a User Story for a Requirement (Mapped Node)
# -------------------------------
async def generate_story(state: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    req = state["requirement"]
    logger.debug(f"GENERATE_STORY: Generating story for requirement ID: {req.get('id')}")
    epic_llm = llm.with_structured_output(schema=UserStoryDescription)\
                  .with_retry(retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                              stop_after_attempt=5, wait_exponential_jitter=True)
    prompt = (
        f"Write a user story based on the following requirement:\n"
        f"Actor: {req.get('actor')}\nAction/Need: {req.get('action')}\nConstraint: {req.get('constraint') or 'None'}\n\n"
        "The story should follow: \"As a <actor>, I want to <action> [under <constraint>] so that <benefit>.\" "
        "Return a JSON with key 'desc'."
    )
    response = await epic_llm.ainvoke(prompt)
    story_text = json.loads(response.model_dump_json(indent=4))["desc"]
    return {
        "story": {
            "id": req["id"],
            "epic": req["epic"],
            "actor": req.get("actor"),
            "action": req.get("action"),
            "constraint": req.get("constraint"),
            "description": story_text
        }
    }

# -------------------------------
# NODE 8: Merge User Stories (Reduce Node)
# -------------------------------
def merge_stories(state: AgentState, mapped_results: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    stories = [res["story"] for res in mapped_results]
    logger.debug(f"MERGE_STORIES: Merged {len(stories)} stories.")
    return {"stories": stories}

# -------------------------------
# MAPPING FUNCTION: Send Each Story for Acceptance Criteria Processing
# -------------------------------
def map_stories(state: AgentState) -> List[Send]:
    return [Send("process_acceptance", {"story": story}) for story in state["stories"]]

# -------------------------------
# NODE 9: Process Acceptance Criteria for a Story (Mapped Node)
# -------------------------------
async def process_acceptance(state: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    story = state["story"]
    logger.debug(f"PROCESS_ACCEPTANCE: Generating acceptance criteria for story ID: {story['id']}")
    acceptance_llm = llm.with_structured_output(schema=AcceptanceCriteria)\
                        .with_retry(retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                                    stop_after_attempt=7, wait_exponential_jitter=True)
    prompt = (
        f"You are a QA engineer. Write suitable acceptance criteria for the following user story:\n"
        f"\"{story['description']}\"\n\n"
        "Return a JSON list of strings (key: 'criteria')."
    )
    response = await acceptance_llm.ainvoke(prompt)
    criteria_list = json.loads(response.model_dump_json(indent=4))['criteria']
    story["acceptance_criteria"] = criteria_list if isinstance(criteria_list, list) else [criteria_list]
    return {"story": story}

# -------------------------------
# NODE 10: Merge Acceptance Criteria Results (Reduce Node)
# -------------------------------
def merge_acceptance(state: AgentState, mapped_results: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    stories = [res["story"] for res in mapped_results]
    logger.debug("MERGE_ACCEPTANCE: Updated stories with acceptance criteria.")
    return {"stories": stories}

# -------------------------------
# NODE 11: Manage Dependencies
# -------------------------------
async def manage_dependencies(state: AgentState, config: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    logger.debug("MANAGE_DEPENDENCIES: Analyzing story dependencies.")
    stories = state["stories"]
    dependency_llm = llm.with_structured_output(schema=Dependencies)\
                        .with_retry(retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                                    stop_after_attempt=5, wait_exponential_jitter=True)
    story_list_text = "\n".join([f"{s['id']}. {s['description']}" for s in stories])
    prompt = (
        "Analyze the following user stories and output dependencies as JSON with key 'dependencies' (an array of objects with 'id' and 'Dependency').\n\n"
        "User Stories:\n" + story_list_text
    )
    response = await dependency_llm.ainvoke(prompt)
    dependencies = json.loads(response.model_dump_json(indent=4))['dependencies']
    if not isinstance(dependencies, list):
        dependencies = []
    for dependency in dependencies:
        story_id = dependency["id"]
        story = next((s for s in stories if s["id"] == story_id), None)
        if story:
            story["dependencies"] = dependency["Dependency"]
    return {"stories": stories}

# -------------------------------
# NODE 12: Prioritize Stories
# -------------------------------
async def prioritize_stories(state: AgentState, config: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    logger.debug("PRIORITIZE_STORIES: Prioritizing user stories.")
    stories = state["stories"]
    story_summaries = "\n".join([f"{s['id']}. {s['description']}" for s in stories])
    priority_llm = llm.with_structured_output(schema=Prioritization)\
                      .with_retry(retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                                  stop_after_attempt=5, wait_exponential_jitter=True)
    prompt = (
        "You are a product owner. Prioritize the following user stories based on impact and urgency. "
        "Return JSON with key 'priorities' as an array of objects with 'id' and 'priority'.\n\n"
        "User Stories:\n" + story_summaries
    )
    response = await priority_llm.ainvoke(prompt)
    priority_list = json.loads(response.model_dump_json(indent=4))['priorities']
    id_to_priority = {item.get("id"): item.get("priority") for item in priority_list if item}
    for story in stories:
        story["priority"] = id_to_priority.get(story["id"], "Medium")
    return {"stories": stories}

# -------------------------------
# NODE 13: Plan Sprints
# -------------------------------
async def plan_sprints(state: AgentState, config: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    logger.debug("PLAN_SPRINTS: Planning sprints for user stories.")
    stories = state["stories"]
    num_sprints = config["configurable"].get("num_sprints", 3)
    sprint_plan_llm = llm.with_structured_output(schema=Sprints)\
                         .with_retry(retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                                     stop_after_attempt=5, wait_exponential_jitter=True)
    story_info_lines = []
    for s in stories:
        dep_str = f" (Depends on: {s.get('dependencies')})" if s.get("dependencies") else ""
        story_info_lines.append(f"{s['id']}. {s['description']} - Priority: {s.get('priority', 'Medium')}{dep_str}")
    story_info_text = "\n".join(story_info_lines)
    prompt = (
        f"You are a Scrum Master planning a project across {num_sprints} sprints. Distribute the following user stories into sprints 1 to {num_sprints}, respecting dependencies and priorities.\n\n"
        "Stories:\n" + story_info_text + "\n\n"
        "Return JSON with key 'sprints' as an array of objects like {'id': <story_id>, 'sprint': <sprint_number>}."
    )
    response = await sprint_plan_llm.ainvoke(prompt)
    assignment = json.loads(response.model_dump_json(indent=4))['sprints']
    id_to_sprint = {item.get("id"): item.get("sprint") for item in assignment if item}
    for story in stories:
        story["sprint"] = id_to_sprint.get(story["id"], None)
    return {"stories": stories}

# -------------------------------
# NODE 14: (Optional) Refine Stories
# -------------------------------
def refine_stories(state: AgentState) -> Dict[str, List[Dict[str, Any]]]:
    logger.debug("REFINE_STORIES: Refinement not implemented; passing stories through.")
    return {"stories": state["stories"]}

# -------------------------------
# NODE 15: Format Final Output
# -------------------------------
def format_output(state: AgentState) -> Dict[str, Dict[str, Any]]:
    logger.debug("FORMAT_OUTPUT: Formatting final output grouped by epic.")
    epics = state["epics"]
    final_stories = state["stories"]
    output = {"epics": []}
    for epic in epics:
        epic_name = epic.get("epic_name") or epic.get("name") or epic.get("title") or "Miscellaneous"
        epic_entry = {"epic": epic_name, "stories": []}
        for story in final_stories:
            if epic_name in story.get("epic", []):
                epic_entry["stories"].append({
                    "id": story.get("id"),
                    "description": story.get("description"),
                    "acceptance_criteria": story.get("acceptance_criteria", []),
                    "dependencies": story.get("dependencies", []),
                    "priority": story.get("priority"),
                    "sprint": story.get("sprint")
                })
        output["epics"].append(epic_entry)
    return {"final_output": output}

# -------------------------------
# BUILDING THE GRAPH
# -------------------------------
graph = StateGraph(AgentState)

# Sequential nodes
graph.add_node("extract_req_config", extract_req_config)
graph.add_node("split_document", split_document)

# Map-Reduce for requirements extraction
graph.add_conditional_edges("split_document", map_chunks, ["process_chunk_node"])
graph.add_node("process_chunk_node", process_chunk_node)
graph.add_node("merge_requirements", merge_requirements)
graph.add_edge("process_chunk_node", "merge_requirements")
graph.add_edge("merge_requirements", "breakdown_epics")

# Add remaining nodes
graph.add_node("breakdown_epics", breakdown_epics)
graph.add_node("assign_epics", assign_epics)
graph.add_edge("breakdown_epics", "assign_epics")

# Map-Reduce for user story generation
graph.add_conditional_edges("assign_epics", map_requirements, ["generate_story"])
graph.add_node("generate_story", generate_story)
graph.add_node("merge_stories", merge_stories)
graph.add_edge("generate_story", "merge_stories")

# Map-Reduce for acceptance criteria generation
graph.add_conditional_edges("merge_stories", map_stories, ["process_acceptance"])
graph.add_node("process_acceptance", process_acceptance)
graph.add_node("merge_acceptance", merge_acceptance)
graph.add_edge("process_acceptance", "merge_acceptance")

# Sequential nodes for further processing
graph.add_node("manage_dependencies", manage_dependencies)
graph.add_node("prioritize_stories", prioritize_stories)
graph.add_node("plan_sprints", plan_sprints)
graph.add_node("refine_stories", refine_stories)
graph.add_node("format_output", format_output)

graph.add_edge("merge_acceptance", "manage_dependencies")
graph.add_edge("manage_dependencies", "prioritize_stories")
graph.add_edge("prioritize_stories", "plan_sprints")
graph.add_edge("plan_sprints", "refine_stories")
graph.add_edge("refine_stories", "format_output")
graph.add_edge("format_output", END)

# Compile the graph application.
app = graph.compile()
