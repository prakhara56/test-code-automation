import asyncio
from loguru import logger

from code_manager.models import AgentState
# from code_manager.tools import search_code
from code_manager.tools import make_search_code_tool

from langchain_core.runnables.config import RunnableConfig

async def process_step(i, step, n, search_code):
    logger.info(f"QUERYING STEP {i} WITH DATABASE")

    query_ans = await search_code.ainvoke(
        {
            "query_text":step,
            "n_results":n
        }
    )
    # logger.info(f"QUERYING STEP {i} WITH DATABASE COMPLETE")
    return {'query':step, 'snippets':query_ans}


async def query_steps(state: AgentState, config:RunnableConfig):
    plan = state['plan']
    n=config['configurable'].get('n_search', 5)
    logger.debug("Agent Node: QUERYING STEPS WITH DATABASE")
    clone_dir = state.get('clone_dir', None)
    repo_name = state.get('repo_name', None)

    search_code = make_search_code_tool(clone_dir=clone_dir, repo_name=repo_name)
    
    tasks = [asyncio.create_task(process_step(i,step,n,search_code)) for i,step in enumerate(plan)]
    fetched_snippets = await asyncio.gather(*tasks)

    return  {'fetched_snippets':fetched_snippets}