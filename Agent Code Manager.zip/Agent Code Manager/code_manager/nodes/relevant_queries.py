import asyncio
import openai
from loguru import logger

from code_manager.models import AgentState,RelevantQueries
from code_manager.llm import llm
from code_manager.prompts import relevant_snippet_prompt

from langchain_core.runnables import RunnableSerializable


# from langchain_core.runnables.config import RunnableConfig

# async def process_step(i, query, relevant_chain: RunnableSerializable):
#     logger.info(f"Sending query {i} to LLM")

#     retry = 0
#     while retry < 3:
#         do_retry = False
#         print("aagaya")
#         breakpoint()
#         output: RelevantQueries = await relevant_chain.ainvoke(
#             {
#                 'query': query['query'],
#                 'snippets': query['snippets']
#             }
#         )
#         print(output)
#         relevant_indices = output.model_dump()['indices']

#         # Check if all indices are within bounds
#         for index in relevant_indices:
#             if index >= len(query['snippets']):
#                 do_retry = True
#                 logger.warning(f"Invalid index {index} at step {i}, retrying...")
#                 break

#         if not do_retry:
#             selected_snippets = [query['snippets'][index] for index in relevant_indices]
#             return {
#                 'query': query['query'],
#                 'snippets': selected_snippets
#             }

#         retry += 1

#     logger.error(f"Failed to get valid indices after 3 retries for step {i}")
#     return {
#         'query': query['query'],
#         'snippets': []  # fallback: empty list
#     }

async def process_step(i, query, relevant_chain: RunnableSerializable):
    logger.info(f"Sending query {i} to LLM")

    retry = 0
    while retry < 3:
        do_retry = False
        # print("aagaya")
        # breakpoint()  # You can remove this for production

        try:
            output: RelevantQueries = await relevant_chain.ainvoke({
                'query': query['query'],
                'snippets': query['snippets']
            })
        except Exception as e:
            logger.error(f"Invocation failed at step {i} on retry {retry + 1}: {e}")
            retry += 1
            continue

        print(output)

        # Safely extract indices
        try:
            relevant_indices = output.model_dump()['indices']
        except KeyError:
            logger.warning(f"No 'indices' key found in output at step {i}")
            retry += 1
            continue

        # Validate indices
        for index in relevant_indices:
            if index >= len(query['snippets']):
                do_retry = True
                logger.warning(f"Invalid index {index} at step {i}, retrying...")
                break

        if not do_retry:
            selected_snippets = [query['snippets'][index] for index in relevant_indices]
            return {
                'query': query['query'],
                'snippets': selected_snippets
            }

        retry += 1  # Move this here to ensure it's retried if invalid indices are found

    logger.error(f"Failed to get valid indices after 3 retries for step {i}")
    return {
        'query': query['query'],
        'snippets': []  # fallback: empty list
    }


    
    

async def find_relevant_queries(state: AgentState):
    fetched_snippets = state['fetched_snippets']
    logger.debug("Agent Node: FINDING RELEVANT FUNCTIONS IN DATABASE!")

    relevant_query_llm = llm.with_structured_output(schema=RelevantQueries)\
                        .with_retry(
                            retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                            stop_after_attempt=7,
                            wait_exponential_jitter=True
                        )

    relevant_query_chain = relevant_snippet_prompt | relevant_query_llm

    tasks = [asyncio.create_task(process_step(i, query, relevant_query_chain)) for i,query in enumerate(fetched_snippets)]
    relevant_snippets = await asyncio.gather(*tasks)

    return {'relevant_snippets':fetched_snippets}