from loguru import logger

from code_manager.models import AgentState
from code_manager.utils import read_scenarios, compare_step


# def match_with_snippets(gherkin_step,snippets):
#     for item in snippets:
#         for snippet in item.get("snippets", []):
#             text = snippet.get("text", "")
#             lines = [line.strip() for line in text.split("\n")]
            
#             for line in lines:
#                 if compare_step(line, gherkin_step, 1):
#                     logger.info(f"Matched step: {line} with {gherkin_step} at file {snippet.get('path', '')}")
#                     return True
    
#     return False

def match_with_snippets(gherkin_step, snippets):
    for item in snippets:
        for snippet in item.get("snippets", []):
            # if snippet is a dict, pull out text & path; if it's a str, use it directly
            if isinstance(snippet, dict):
                text = snippet.get("text", "")
                path = snippet.get("path", "")
            else:
                text = str(snippet)
                path = item.get("path", "")  # or leave empty if you don't have a path here
            
            # split into lines and strip
            lines = [line.strip() for line in text.split("\n") if line.strip()]
            
            for line in lines:
                if compare_step(line, gherkin_step, 1):
                    logger.info(f"Matched step: {line} with {gherkin_step} at file {path}")
                    return True

    return False


async def match_feature_file(state: AgentState):
    snippets = state['relevant_snippets']
    feature_files = state['feature_files']


    logger.debug("Agent Node: MATCHING FEATURE FILES TO EXISTING ANNOTATIONS!")

   
    gherkin_lines = {
        i: read_scenarios(file['code']) 
        for i, file in enumerate(feature_files)
    }

    not_matched_steps = [[] for _ in range(len(feature_files))]
    for i, file in gherkin_lines.items():
        for gherkin_step in file:
            if not match_with_snippets(gherkin_step, snippets):
                not_matched_steps[i].append(gherkin_step)
    
    for i, file in enumerate(feature_files):
        file['gherkin_steps_which_do_not_have_step_function'] = not_matched_steps[i]
    

    return {"feature_files": feature_files}