from loguru import logger
import openai
import asyncio

from langchain_core.runnables import RunnableSerializable

from code_manager.models import AgentState, FeatureFile
from code_manager.llm import llm
from code_manager.prompts import feature_prompt,feature_react_prompt,feature_output_prompt
from code_manager.subgraph.react_llm2 import react_agent
from code_manager.utils import convert_simulation_messages

async def process_step(i, inputs, file, feature_chain:RunnableSerializable):
    logger.info(f"Sending query {i} to LLM")
    output: FeatureFile = await feature_chain.ainvoke(
        {
            'snippets': inputs['snippets'],
            'action_input': inputs['action_input'],
            'testcase': inputs['testcase'],
            'project_files': file,
            'code_summary_from_codebase':inputs['summary']
        }
    )
    return output.feature_file


async def feature_file_generation(state: AgentState):
    relevant_snippets = state['relevant_snippets']
    project_files = state['project_files']
    recorded_steps = state['recorded_steps']
    testcase = state['testcase']
    code_summary = state['plan_summary']

    clone_dir = state.get('clone_dir', None)
    repo_name = state.get('repo_name', None)

    inputs = {
        "snippets": relevant_snippets,
        "action_input": recorded_steps,
        "testcase": testcase,
        "summary":code_summary
    }

    logger.debug("Agent Node: GENERATING FEATURE FILES!")
    # feature_files_to_be_generated = [file for file in project_files if file['file_type'] == 'feature']
    # print(feature_files_to_be_generated)
    

    feature_llm = llm.with_structured_output(schema=FeatureFile)\
                        .with_retry(
                            retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                            stop_after_attempt=7,
                            wait_exponential_jitter=True
                        )

    feature_chain = feature_output_prompt | feature_llm

    # tasks = [asyncio.create_task(process_step(i, inputs, file, feature_chain)) for i,file in enumerate(feature_files_to_be_generated)]
    # codes = await asyncio.gather(*tasks)

    react_msg = feature_prompt.invoke(
        {
            'snippets': inputs['snippets'],
            'action_input': inputs['action_input'],
            'testcase': inputs['testcase'],
            'code_summary_from_codebase':inputs['summary']
        }
    ).to_string()

    react_ans = await react_agent(react_msg,feature_react_prompt,60,clone_dir=clone_dir, repo_name=repo_name)
    messages = convert_simulation_messages(react_ans)
    react_messages = [{'role':message['role'],'content':message['content']} for message in messages if message['role']=='ai' or message['role']=='human']


    output:FeatureFile = await feature_chain.ainvoke({"response":react_messages})

    feature_file = output.model_dump()

    logger.info(f"generated feature files are:\n {feature_file}")

    # feature_file_code = [{'code':codes[i],**file} for i,file in enumerate(feature_files_to_be_generated)]
    feature_file_code = [feature_file]

    return {'feature_files':feature_file_code}