from loguru import logger
import openai
import asyncio
import json

from langchain_core.runnables import RunnableSerializable
from langchain.output_parsers import PydanticOutputParser
from langchain_core.prompt_values import StringPromptValue

from code_manager.models import AgentState, PageFunctionFile
from code_manager.llm import llm
from code_manager.prompts import page_function_prompt, page_format_output, page_react_system_prompt
from code_manager.subgraph.react_llm2 import react_agent, State

# from react_page import react_page, State
import mdextractor
import copy



async def process_step(i, inputs, file, page_function_chain:RunnableSerializable, codes:list):
    logger.info(f"Sending query {i} to LLM")
    input = {
        'snippets': inputs['snippets'],
        'action_input': inputs['action_input'],
        # 'testcase': inputs['testcase'],
        'feature_files': inputs['feature_files'],
        'project_files': file,
        "other_generated_files": codes
    }

    # output: PageFunctionFile = await page_function_chain.ainvoke(inputs)
    # return output.page_functions

    input_message: StringPromptValue = await page_function_prompt.ainvoke(input)
    # print(input_message)
    output: State  = await react_agent(input_message.text, page_react_system_prompt,clone_dir=inputs["clone_dir"], repo_name=inputs["repo_name"])
    response_to_be_formatted = {'chatbot':output['messages'][-2].content,'simulated_user':output['messages'][-1].content}
    formatted_output: PageFunctionFile = await page_function_chain.ainvoke({'response':response_to_be_formatted})

    return formatted_output.model_dump()


async def page_function_generation(state: AgentState):
    relevant_snippets = state['relevant_snippets']
    project_files = state['project_files']
    recorded_steps = state['recorded_steps']
    testcase = state['testcase']
    feature_files = copy.deepcopy(state['feature_files'])
    clone_dir = state.get('clone_dir', None)
    repo_name = state.get('repo_name', None)

    feature_files = [file.get("gherkin_steps_which_do_not_have_step_function", None) for file in feature_files if len(file['gherkin_steps_which_do_not_have_step_function'])>0]

    inputs = {
        "snippets": relevant_snippets,
        "action_input": recorded_steps,
        "testcase": testcase,
        "feature_files": feature_files,
        "clone_dir": clone_dir,
        "repo_name": repo_name
    }

    logger.debug("Agent Node: GENERATING PAGE FUNCTION FILES!")
    page_functions_to_be_generated = [file for file in project_files if file['file_type'] == 'page']
    print(page_functions_to_be_generated)
    
    page_llm = llm.with_retry(
                    retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                    stop_after_attempt=7,
                    wait_exponential_jitter=True
                )
    
   
    
    parser = PydanticOutputParser(pydantic_object=PageFunctionFile)

    # prompt = page_function_prompt.invoke({
    #         'snippets': inputs['snippets'],
    #         'action_input': inputs['action_input'],
    #         'testcase': inputs['testcase'],
    #         'feature_files': inputs['feature_files'],
    #         'project_files': page_functions_to_be_generated[0]
    #     })
        
    # with open("page_prompt.txt","w",encoding='utf-8') as f:
    #     f.write(prompt.to_string())

    page_function_chain = (
        page_format_output
        | page_llm
        | parser
    )

    # tasks = [asyncio.create_task(process_step(i, inputs, file, page_function_chain)) for i,file in enumerate(page_functions_to_be_generated)]
    # codes = await asyncio.gather(*tasks)

    codes = []
    for i, file in enumerate(page_functions_to_be_generated):
        ans = await process_step(i, inputs, file, page_function_chain, codes)
        codes.append(ans)
    print(f"Generated page function files are:\n {codes}")

    page_function_code = [{'code':codes[i],**file} for i,file in enumerate(page_functions_to_be_generated)]

    # print(state['feature_files'])
    
    return {'page_functions':page_function_code}