import json
from loguru import logger
from code_manager.models import AgentState
from code_manager.prompts import react_prompt_for_planning,react_prompt_for_planning_system_prompt
from code_manager.subgraph.react_llm2 import react_agent
from code_manager.utils import convert_simulation_messages




async def check_codebase_for_plan_summary(state:AgentState):
    logger.debug("Agent Node: CHECKING CODEBASE FOR PLAN SUMMARY")

    testcase = state['testcase']
    recorded_steps = state['recorded_steps']
    plan = state['plan']
    clone_dir = state.get('clone_dir', None)
    repo_name = state.get('repo_name', None)
    print(clone_dir)
    print(repo_name)

    initial_msg = react_prompt_for_planning.invoke({
        "query": plan,
        "recorded_actions": recorded_steps,
        "testcase": testcase
    })

    output = await react_agent(
        initial_message= initial_msg.to_string(),
        system_prompt_template=react_prompt_for_planning_system_prompt,
        recursion_limit=100,
        clone_dir=clone_dir, 
        repo_name=repo_name
    )

    messages = convert_simulation_messages(output)

    state['relevant_snippets'] = [{"snippets":snippets['content']} for snippets in messages if snippets['role']=='tool' and snippets['content']]
    state['plan_summary'] = [message['content'] for message in messages if message['role']=='ai']
    state['plan_react_ans'] = messages

    return state

