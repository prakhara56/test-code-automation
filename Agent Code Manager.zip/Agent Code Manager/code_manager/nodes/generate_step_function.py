from loguru import logger
import openai
import asyncio
import json

from langchain_core.runnables import RunnableSerializable
from langchain.output_parsers import PydanticOutputParser
from langchain_core.prompt_values import StringPromptValue
from langchain_core.messages import BaseMessage

from code_manager.models import AgentState, StepFunctionFile
from code_manager.llm import llm
from code_manager.prompts import step_function_prompt, step_format_output, step_react_system_prompt
from code_manager.subgraph.react_llm2 import react_agent, State

# from react_step import react_step, State
import mdextractor
import copy



async def process_step(i, inputs, file, step_function_chain:RunnableSerializable, codes:list):
    logger.info(f"Sending query {i} to LLM")
    input = {
        "snippets": inputs['snippets'],
        "page_function_file": inputs['page_functions'],
        # "testcase": test_run['testcase'],
        "feature_files": inputs['feature_files'],
        "project_files": file, #inputs['project_files']
        "other_generated_files": codes
    }

    # output: PageFunctionFile = await page_function_chain.ainvoke(inputs)
    # return output.page_functions

    input_message: StringPromptValue = await step_function_prompt.ainvoke(input)
    # print(input_message)
    output: State  = await react_agent(input_message.text, step_react_system_prompt,clone_dir=inputs["clone_dir"], repo_name=inputs["repo_name"])
    
    response_to_be_formatted = {'chatbot':output['messages'][-2].content,'simulated_user':output['messages'][-1].content}
    formatted_output: StepFunctionFile = await step_function_chain.ainvoke({'response':response_to_be_formatted})

    return formatted_output.model_dump()


async def step_function_generation(state: AgentState):
    relevant_snippets = state['relevant_snippets']
    project_files = state['project_files']
    recorded_steps = state['recorded_steps']
    testcase = state['testcase']
    feature_files = copy.deepcopy(state['feature_files'])
    page_functions = state['page_functions']
    clone_dir = state.get('clone_dir', None)
    repo_name = state.get('repo_name', None)

    feature_files = [file.get("gherkin_steps_which_do_not_have_step_function", None) for file in feature_files if len(file['gherkin_steps_which_do_not_have_step_function'])>0]
    
    inputs = {
        "snippets": relevant_snippets,
        "action_input": recorded_steps,
        "testcase": testcase,
        "feature_files": feature_files,
        "page_functions": page_functions,
        "clone_dir": clone_dir,
        "repo_name": repo_name
    }
    
    logger.debug("Agent Node: GENERATING STEP FUNCTION FILES!")
    step_functions_to_be_generated = [file for file in project_files if file['file_type'] == 'step']
    print(step_functions_to_be_generated)
    
    step_llm = llm.with_retry(
                    retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                    stop_after_attempt=7,
                    wait_exponential_jitter=True
                )
    # page_llm = llm.with_structured_output(schema=PageFunctionFile)\
    #                     .with_retry(
    #                         retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
    #                         stop_after_attempt=7,
    #                         wait_exponential_jitter=True
    #                     )

    # page_function_chain = page_function_prompt | page_llm

    parser = PydanticOutputParser(pydantic_object=StepFunctionFile)


    step_function_chain = (
        step_format_output
        | step_llm
        | parser
    )

    # tasks = [asyncio.create_task(process_step(i, inputs, file, step_function_chain)) for i,file in enumerate(step_functions_to_be_generated)]
    # codes = await asyncio.gather(*tasks)

    codes = []
    for i, file in enumerate(step_functions_to_be_generated):
        ans = await process_step(i, inputs, file, step_function_chain, codes)
        codes.append(ans)

    print(f"Generated step function files are:\n {codes}")
    
    step_function_code = [{'code':codes[i],**file} for i,file in enumerate(step_functions_to_be_generated)]

    # print(state['feature_files'])
    
    return {'step_functions':step_function_code}