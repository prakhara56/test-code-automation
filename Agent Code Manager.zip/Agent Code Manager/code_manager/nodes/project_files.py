import asyncio
import openai
from loguru import logger

from code_manager.models import AgentState, ProjectFiles
from code_manager.llm import llm    
# from code_manager.tools import project_structure
from code_manager.tools import (
    make_project_structure_tool,
)

from code_manager.prompts import project_files_prompt
from langchain_core.runnables.config import RunnableConfig
from langchain.output_parsers import PydanticOutputParser

async def generate_automation_files(state:AgentState, config:RunnableConfig):
    logger.debug("Agent Node: GENERATING AUTOMATION FILES")

    testcase = state['testcase']
    recorded_steps = state['recorded_steps']
    snippets = state['relevant_snippets']
    code_summary = state['plan_summary']
    clone_dir = state.get('clone_dir', None)
    repo_name = state.get('repo_name', None)
    
    index_path = config['configurable'].get('index_path', 'Repo_Index/repo_index.json')
    project_structure = make_project_structure_tool(clone_dir=clone_dir, repo_name=repo_name)

    repo_structure = await project_structure.ainvoke({})

    project_files_llm = llm.with_retry(
                            retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
                            stop_after_attempt=7,
                            wait_exponential_jitter=True
                        )

    # project_files_llm = llm.with_structured_output(schema=ProjectFiles)\
    #                     .with_retry(
    #                         retry_if_exception_type=(openai.RateLimitError, openai.APIConnectionError),
    #                         stop_after_attempt=7,
    #                         wait_exponential_jitter=True
    #                     )

    project_files_chain = project_files_prompt | project_files_llm | PydanticOutputParser(pydantic_object=ProjectFiles) 
    output_files:ProjectFiles = await project_files_chain.ainvoke(
        {
            "testcase":testcase,
            "action_input":recorded_steps,
            "snippets":snippets,
            "project_structure":repo_structure,
            'code_summary_from_codebase':code_summary
        }
    ) 

    project_files = output_files.model_dump()['project_files']  
    logger.info(f"PROJECT FILES: {project_files}")

    return {'project_files':project_files} 