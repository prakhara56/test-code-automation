from bs4 import BeautifulSoup
import os
from typing import List,Dict, Tuple, Literal
from loguru import logger
import json

import re
import openai
from langgraph.graph.graph import CompiledGraph,Graph
from langgraph.pregel import RetryPolicy


def html_to_dict(html: str, length_limit: int = 50) -> dict:
    """
    Parses an HTML string and converts it into a dictionary with a specified character length limit.
    
    Args:
        html (str): The HTML content to parse.
        length_limit (int, optional): The maximum character limit for each value. Defaults to 50.

    Returns:
        dict: A dictionary containing parsed HTML elements with truncated values.
    """
    soup = BeautifulSoup(html, 'html.parser')
    result = {}
    
    def truncate_value(value):
        """Truncates various data types to the specified length limit."""
        if isinstance(value, list):
            return [truncate_value(v) for v in value]
        elif isinstance(value, dict):
            return {k[:length_limit]: truncate_value(v) for k, v in value.items()}
        elif isinstance(value, str):
            return value[:length_limit]
        elif isinstance(value, (int, float)):
            return str(value)[:length_limit]
        elif isinstance(value, tuple):
            return tuple(truncate_value(v) for v in value)
        elif isinstance(value, set):
            return {truncate_value(v) for v in value}
        return value
    
    def parse_element(element):
        """Recursively parses an HTML element and extracts attributes and content."""
        tag_name = element.name[:length_limit] if element.name else None
        if not tag_name:
            return None
        
        tag_info = {
            "attributes": {k[:length_limit]: truncate_value(v) for k, v in element.attrs.items()},
            "content": element.text.strip()[:length_limit]
        }
        
        if tag_name in result:
            result[tag_name].append(tag_info)
        else:
            result[tag_name] = [tag_info]
        
        for child in element.find_all(recursive=False):
            parse_element(child)
    
    for element in soup.find_all(recursive=False):
        parse_element(element)
    
    return result



def save_graph_to_file(runnable_graph:CompiledGraph, output_file_path:str, as_save:Literal['ascii','mermaid'] = 'mermaid')->None:
        """Saves the graph to a file."""
        if not os.path.exists(os.path.dirname(output_file_path)):
            os.makedirs(os.path.dirname(output_file_path))
        if as_save == 'ascii':
            runnable_graph.get_graph().draw_ascii(output_file_path)
            with open(output_file_path, 'w') as file:
                file.write(png_bytes)
        elif as_save == 'mermaid':
            png_bytes = runnable_graph.get_graph().draw_mermaid_png()
            with open(output_file_path, 'wb') as file:
                file.write(png_bytes)
        else:
            raise ValueError("Invalid save type. Must be 'ascii' or 'mermaid'.")
        # runnable_graph.get_graph().draw_mermaid_png()


def add_nodes(workflow:Graph, nodes:Dict)->Graph:
    """Adds nodes to the graph."""
    for node_name, node in nodes.items():
        workflow.add_node(node_name, node)
    return workflow

def add_retry_nodes(workflow:Graph, nodes:Dict)->Graph:
    """Adds retry nodes to the graph."""
    for node_name, node, retry_policy in nodes.items():
        workflow.add_node(node_name, node, retry = retry_policy)
    return workflow

def add_edges(workflow:Graph, edges:List[Tuple])->Graph:
    """Adds edges to the graph."""
    for edge in edges:
        workflow.add_edge(edge[0], edge[1])
    return workflow

def add_conditional_edges(workflow:Graph, edges:List[Tuple])->Graph:
    """
    Adds conditional edges to the graph. In the edges tuple pass the starting node and decider function.
    Also Decider Function should return the Literal of the next Edges.
    """
    for edge in edges:
        workflow.add_conditional_edges(edge[0], edge[1], edge[2])
    return workflow


def process_recorded_actions(actions: List[Dict])->List[Dict]:
    """Processes the recorded actions."""
    for action in actions:
        if 'outerHTML' in action:
            action['breakdownHTML'] = html_to_dict(action['outerHTML'])
            del action['outerHTML']
        
        # Create a list of keys to remove to avoid RuntimeError
        keys_to_delete = [tag for tag in action if action[tag] in [None, '', [], {}, ()]]
       
        for tag in keys_to_delete:
            del action[tag]
    
    return actions

def process_user_context(user_context:str)->str:
    """Processes the user context."""
    if user_context:
        return user_context
    else:
        return None
    


    



def openai_retry_on(exc: Exception) -> bool:
    import httpx
    import requests

    if isinstance(exc, ConnectionError):
        return True
    if isinstance(
        exc,
        (
            ValueError,
            TypeError,
            ArithmeticError,
            ImportError,
            LookupError,
            NameError,
            SyntaxError,
            RuntimeError,
            ReferenceError,
            StopIteration,
            StopAsyncIteration,
            OSError,
            openai.RateLimitError, 
            openai.APIConnectionError
        ),
    ):
        return False
    if isinstance(exc, httpx.HTTPStatusError):
        return 500 <= exc.response.status_code < 600
    if isinstance(exc, requests.HTTPError):
        return 500 <= exc.response.status_code < 600 if exc.response else True
    return True


def preprocess_sentence(sentence):
        """
        Preprocesses a Gherkin sentence by removing Given/When/Then/And keywords.

        Parameters:
        - sentence (str): Gherkin step to preprocess.

        Returns:
        - str: Preprocessed sentence.
        """
        return re.sub(r'^(Given|When|Then|And)\s', '', sentence, flags=re.IGNORECASE).strip()


def compare_step(entry, step, state):
        """
        Compares a Gherkin step against a scenario entry using regex matching.

        Args:
            - entry (str): Annotation entry to match against.
            - step (str): Gherkin step to match.
            - state (int): Matching state indicator (1 for exact match, 2 for fuzzy match).

        Returns:
            - bool: True if there's a match, False otherwise.
        """
        pattern = re.compile(r'@(Then|When|Given|And)\("((?:[^"()]|(?:"(?:[^"])*"))*)"\)', flags=re.IGNORECASE)
        match = pattern.search(entry)
        if match:
            keyword = match.group(1)
            extracted_text = match.group(2)
            extracted_text_regex = re.sub(r'\{(\w+)\}', r'(.*)', extracted_text, flags=re.IGNORECASE)

            if state == 1:
                cucumber_matcher = re.compile(f'^{keyword} {extracted_text_regex}$', flags=re.IGNORECASE)
            else:
                step = preprocess_sentence(step)
                cucumber_matcher =  re.compile(f'^{extracted_text_regex}$', flags=re.IGNORECASE)

            return cucumber_matcher.match(step) is not None
        return False


def read_scenarios(gherkin_file: str)->list:
    gherkin_scenarios = []
    step_keywords = {"given", "when", "then", "and"}

    
    lines = gherkin_file.splitlines() if isinstance(gherkin_file, str) else gherkin_file
    previous_keyword = None

    for line in lines:
        stripped = line.strip()
        lowered = stripped.lower()

        if not any(lowered.startswith(k) for k in step_keywords):
            continue  # skip lines that don't start with a step keyword

        if lowered.startswith("and") and previous_keyword:
            # Replace "And" with the previous keyword
            transformed = f"{previous_keyword} {stripped[4:].strip()}"
            gherkin_scenarios.append(transformed)
        else:
            keyword = lowered.split()[0].capitalize()
            previous_keyword = keyword
            gherkin_scenarios.append(stripped)

    return gherkin_scenarios


from typing import List, Dict, Any

def convert_simulation_messages(simulation: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Converts simulation['messages'] into a list of dictionaries with 'role' and 'content' keys.
    Role is determined as 'ai', 'human', or 'tool' based on the message class name.
    """
    logger.info("Converting simulated messages...")
    result = []
    for msg in simulation.get('messages', []):
        # Determine role by class name
        class_name = msg.__class__.__name__
        role = class_name.replace('Message', '').lower()  # e.g., AIMessage -> 'ai'
        if role not in ('ai', 'human', 'tool'):
            role = 'unknown'
        
        # Build the entry
        entry = {
            'role': role,
            'content': msg.content
        }

        json_ans = None
        try:
            json_ans = json.loads(msg.content)
        except:
            pass

        if json_ans:
            entry['content'] = json_ans
            # print(json_ans)
        
        # Optionally include other attributes
        # For tool messages, include tool name and id
        if hasattr(msg, 'name'):
            entry['name'] = msg.name
        if hasattr(msg, 'tool_call_id'):
            entry['tool_call_id'] = msg.tool_call_id
        
        result.append(entry)
    
    return result

