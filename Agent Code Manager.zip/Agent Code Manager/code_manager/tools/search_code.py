import os
import json
from typing import Dict, Any, List, Optional
from loguru import logger

from langchain.tools import tool

from code_search.hybrid_storage import hybrid_load
from code_search.vector_search import search_query
from code_search.tree_node import TreeNode

def make_search_code_tool(
    clone_dir: str,
    repo_name: str,
    model_endpoint: str = "http://127.0.0.1:8000"
):
    """
    clone_dir: folder where your indexes live (e.g. "/mnt/data/indexes")
    repo_name: name of the repo (so you'll load index_dir/<repo_name>.json)
    model_endpoint: e.g. "http://127.0.0.1:8000"
    """
    index_path = os.path.join(clone_dir, "indexes", f"{repo_name}.json")
    embeddings_path = os.path.join(clone_dir, "indexes", f"{repo_name}.embeddings")

    @tool(
        description=(
            "Searches a code repo using a hybrid index. "
            "Takes a natural-language query and returns top code matches."
        )
    )
    def search_code(
        query_text: str,
        n_results: int = 5
    ) -> List[Dict[str, Any]]:
        # build args for your hybrid loader
        args = {
            "path_to_index": index_path,
            "query_text": query_text,
            "n_results": n_results,
        }

        # load your index + dataset
        tree_root, dataset = hybrid_load(index_path,embeddings_path)

        # point at your chosen model endpoint
        model = model_endpoint  # e.g. SentenceTransformer(...) or a URL

        logger.info(f"Searching repository index at {index_path}")
        raw = search_query(args, model, dataset)

        # strip out embeddings before returning
        cleaned = [
            {
                "match_score": score,
                **{k: v for k, v in meta.items() if k != "embedding"}
            }
            for score, meta in raw
        ]
        return cleaned

    return search_code
