import os
import json
from typing import Dict, Any, List, Optional
from loguru import logger

from langchain.tools import tool

from code_search.hybrid_storage import hybrid_load
from code_search.vector_search import search_query
from code_search.tree_node import TreeNode


def make_project_structure_tool(
    clone_dir: str = None,
    repo_name: str = None,
):
    """
    Factory function to create a project_structure tool for a specific repository.

    Args:
        clone_dir (str, optional): The directory where the repository is cloned.
        repo_name (str, optional): The name of the repository.

    Returns:
        callable: A tool function that provides the structure of the project by reading the repo index.
    """

    index_path = os.path.join(clone_dir, "indexes", f"{repo_name}.json")
    @tool(
        description=(
            "Provides the structure of the project by reading the repo index."
        )
    )
    def project_structure() -> str:
        """
    Provides the structure of the project.
        index_path: The path where converted index of the repo is stored. Default is Repo_Index/repo_index.json
    Returns:
        str: A string representation of the project structure.
    """
        logger.debug("Called the project_structure tool")
        tree_root = TreeNode.load_from_file(index_path)
        structure = tree_root.get_directory_structure()
        return structure

    return project_structure



# @tool
# def project_structure(index_path:str = 'Repo_Index/repo_index.json'):
#     """
#     Provides the structure of the project.
#         index_path: The path where converted index of the repo is stored. Default is Repo_Index/repo_index.json
#     Returns:
#         str: A string representation of the project structure.
#     """
#     logger.debug("Called the project_structure tool")
#     tree_root = TreeNode.load_from_file(index_path)
#     structure = tree_root.get_directory_structure()
#     return structure