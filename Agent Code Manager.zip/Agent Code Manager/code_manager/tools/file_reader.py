import os
import json
from loguru import logger
from typing import Optional, Dict, Any
from langchain.tools import tool

def make_repo_file_read_tool(clone_dir: str, repo_name: str):
    """
    Returns a `@tool`-decorated function that knows to read from
    clone_dir/<repo_name> and its index at clone_dir/indexes/<repo_name>.json
    """
    repo_dir = os.path.join(clone_dir, repo_name)
    index_path = os.path.join(clone_dir, "indexes", repo_name + ".json")

    # load index once
    with open(index_path, "r", encoding="utf-8") as f:
        repo_index: Dict[str, Any] = json.load(f)

    def find_file_path(node: Dict[str, Any], target_name: str) -> Optional[str]:
        if node.get("type") == "file" and node.get("name") == target_name:
            return node["path"]
        for child in node.get("children", []):
            result = find_file_path(child, target_name)
            if result:
                return result
        return None

    @tool(
        description=(
            "Given a filename or partial path, returns the file's contents "
            f"from the cloned repo at {repo_dir}. If not indexed or missing on disk, returns an error."
        )
    )
    def read_repo_file(file: str) -> str:
        # normalize to filename
        filename = os.path.basename(file) if ("/" in file or "\\" in file) else file

        # lookup in the in-memory index
        logger.debug(f"Searching for file '{filename}' in index at {index_path}")
        rel_path = find_file_path(repo_index, filename)
        if not rel_path:
            return f"File '{file}' not found in index at {index_path}"

        # build absolute on-disk path
        abs_path = os.path.join(clone_dir, rel_path)
        if not os.path.isfile(abs_path):
            return f"Indexed path exists but no file on disk: {abs_path}"

        try:
            return open(abs_path, "r", encoding="utf-8").read()
        except Exception as e:
            return f"Error reading '{abs_path}': {e}"

    return read_repo_file
