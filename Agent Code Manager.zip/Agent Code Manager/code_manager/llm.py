from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
import os 
from dotenv import load_dotenv
from openai import RateLimitError
load_dotenv()

llm = AzureChatOpenAI(
    api_key=os.environ['AZURE_OPENAI_API_KEY'], # type: ignore
    azure_endpoint=os.environ['AZURE_OPENAI_ENDPOINT'],
    api_version = os.environ["AZURE_OPENAI_API_VERSION"],
    azure_deployment = os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"], 
    temperature=0,
)



embeddings = AzureOpenAIEmbeddings(
    azure_deployment = os.environ["EMBEDDING_OPENAI_MODEL_NAME"],
    api_version = os.environ["EMBEDDING_OPENAI_API_VERSION"]
)




