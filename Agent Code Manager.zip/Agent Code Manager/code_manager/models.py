"""
Defining agent state and result generation formats
"""

from pydantic import BaseModel, Field
from typing import *
import operator


class AgentState(TypedDict):
    recorded_steps: List[Any]
    testcase: str
    plan : List[str] #queries
    plan_summary: List[str]
    plan_react_ans: List[Dict[str,Any]]
    fetched_snippets : List[Any] 
    relevant_snippets : List[Any]
    project_files: List[Dict[str,Any]]
    # generated_code: Annotated[List[Dict],operator.add]
    feature_files: List[Any]
    page_functions: List[Any]
    step_functions: List[Any]
    clone_dir: Optional[str] = None
    repo_name: Optional[str] = None
    

class Plan(BaseModel):
    plan: List[str] = Field(..., description="A list of steps in the plan")

class RelevantQueries(BaseModel):
    indices: List[int] = Field(..., description="A list of all relevant indices where indices start from 0.")
 

class FileDesc(BaseModel):
    file_name: str = Field(..., description="The name of the file")
    file_path: str = Field(..., description="The location of the file within the given project directory")
    file_description: str = Field(...,description="A brief summary of the file’s purpose and what it will contain.")
    file_type: Literal['feature','step','page','utils']


class ProjectFiles(BaseModel):
    project_files: List[FileDesc] = Field(..., description="A list of all project files and their contents")


class FeatureFile(BaseModel):
    # feature_file: str = Field(..., description="A feature file for the given testcase") 
    code: str = Field(..., description="The complete Gherkin feature file content, including Feature, Scenario and all Given/When/Then steps.")
    file_name: str = Field(..., description="The name of the feature file (e.g., 'login.feature').")
    file_path: str = Field(...,description="The relative path where the feature file should be saved (e.g., 'src/test/resources/features/login.feature').")
    gherkin_steps_which_do_not_have_step_function: List[str] = Field(...,description="List of any Gherkin steps you created that did not match an existing step definition.")

class PageFunctionFile(BaseModel):
    page_functions: Dict[str,Any] = Field(..., description="A dictionary with key as the file names of page functions for the given testcase ")
    used_existing_methods: List[str] = Field(..., description="A list of all the existing methods used in the page functions")
    new_methods_summary: List[str] = Field(..., description="A list of all the new methods created in the page functions")

class StepFunctionFile(BaseModel):
    step_function: str = Field(..., description="A file with all the step functions for the given testcase ")