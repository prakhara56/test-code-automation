from loguru import logger
import os

from code_search.hybrid_storage import hybrid_load
from code_search.vector_search import search_query
from code_search.tree_node import TreeNode

from langchain_core.tools import tool
from langchain.tools import Tool
from code_manager.utils import html_to_dict
# from sentence_transformers import SentenceTransformer


# @tool
# def 

html_to_dict_tool = Tool(
    name="HTML Parser",
    func=lambda html, length_limit=50: html_to_dict(html, length_limit),
    description="Parses HTML content and converts it into a dictionary, applying a character length constraint. Default length limit is 50."
)


@tool
def search_code(
        query_text: str,
        n_results: int = 5,
    ):
    """
    Searches for relevant code snippets in a pre-indexed code repository using a hybrid search model.

    Args:
        query_text (str): The natural language query or search phrase used to find relevant code.
        n_results (int, optional): The number of top matching results to return. Defaults to 5.

    Returns:
        List[Dict]: A list of dictionaries representing the top matching code results, each containing relevant metadata.

    Notes:
        - The function loads a hybrid index from the specified `Repo_index` path.
        - Uses the `hybrid_load` and `search_query` functions along with a search model to retrieve results.
    """


    index_path = "Repo_index"

    args = {
        "path_to_index": index_path,
        "query_text": query_text,
        "n_results": n_results,
    }

    tree_root, dataset = hybrid_load(args)
    # model_name_or_path = "model/sentence-t5-base-nlpl-code_search_net"
    model = "http://127.0.0.1:8000"#SentenceTransformer(model_name_or_path)
    
    logger.info("Searching repository at:", os.path.join(args['path_to_index'], "repo_index.json"))
    ans = search_query(args, model, dataset)
    
    cleaned_ans = [
        {
            "match_score": item[0],
            **{k: v for k, v in item[1].items() if k != 'embedding'}
        }
        for item in ans
    ]

    return cleaned_ans

import builtins
REPO_CLONE_DIR = r"C:\Users\Himanshu.Parihar\Downloads\repo_clone_dir"

@tool
def file_reader(path: str) -> str:
    """
    Read the full contents of a text file, using builtins.open.

    - If `path` is absolute, uses it directly.
    - If `path` is relative, resolves under REPO_CLONE_DIR.
    - Strips a leading 'repo_clone_dir' prefix if present.
    """
    # Normalize separators
    p = path.replace("/", os.sep).replace("\\", os.sep)
    logger.debug(f"Called the file_reader tool for {path.split("/")[-1]}")

    # Strip any 'repo_clone_dir' prefix
    marker = f"repo_clone_dir{os.sep}"
    if marker in p:
        p = p.split(marker, 1)[1]

    # Build absolute path
    if os.path.isabs(p):
        abs_path = os.path.normpath(p)
    else:
        abs_path = os.path.normpath(os.path.join(REPO_CLONE_DIR, p))

    # Validate path
    if not os.path.exists(abs_path):
        return f"Error: file not found at '{abs_path}'."
    if not os.path.isfile(abs_path):
        return f"Error: '{abs_path}' is not a regular file."

    # Read with builtins.open
    try:
        with builtins.open(abs_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return f"Error reading file '{abs_path}': {e}"
    

@tool
def project_structure(index_path:str = 'Repo_Index/repo_index.json'):
    """
    Provides the structure of the project.
        index_path: The path where converted index of the repo is stored. Default is Repo_Index/repo_index.json
    Returns:
        str: A string representation of the project structure.
    """
    logger.debug("Called the project_structure tool")
    tree_root = TreeNode.load_from_file(index_path)
    structure = tree_root.get_directory_structure()
    return structure



if __name__ == "__main__":
    # Example usage
    # html_content = """
    # <p>Recognizing we are at this inflection point, at Genentech, we pivoted our approach to make AI a core and integral part of our entire drug discovery and development approach, leading the way in utilizing AI to address major challenges in the process. The foundation of our strategy centers on creating a “lab in a loop,” where data from the lab and clinic feed AI models and algorithms – that are designed by our researchers – to identify trends, make predictions, and generate new molecules. After our scientists conduct experiments based on these predictions and designs, they input the results back into the model, thereby improving its performance across all programs. It's an iterative cycle of data, computation, experimentation and discovery.</p>
    # """

    # html_dict = html_to_dict_tool.invoke(html_content)
    # print(html_dict)
    ans=search_code.invoke({
    "query_text":"User fill the form"
    })
    print(ans)