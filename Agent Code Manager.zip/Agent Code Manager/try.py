import json
with open("outputs/test1_output.json","r") as f:
    data = json.load(f)

query = data['plan']
recorded_actions = data['recorded_steps']
testcase = data['testcase']


prompt = f"""## 🔍 **Prompt: Function Identification and Verification**

You will be given a **query** and a set of **recorded actions**.

You have access to two tools:

1. **Code Search Tool** – Use this to search the codebase using the natural language query.
2. **Codebase Structure Tool** – Use this to explore the full file/folder structure of the codebase.

---

### 🎯 **Your Task**

Use both tools to locate the most relevant function(s) that match the query.

You **must verify whether the function truly corresponds to the query**, taking into account the **recorded actions**. These actions help disambiguate between similar functions by showing which **page**, **component**, or **step** was actually interacted with.

You should also identify and validate any **step definitions** that use these functions. This confirms how and where the function is used in **end-to-end flows or tests**.

---

### ✅ **Verification Checklist**

For each candidate function, validate the following:

#### 1. **Relevance**

* [ ] Does the **function name** or **docstring** clearly relate to the query?
* [ ] Is the function located in a file/module matching the page/component mentioned or implied in the recorded actions?

#### 2. **Behavior Matching**

* [ ] Does the **function logic** match the behavior described in the query?
* [ ] Do its arguments, side effects, or return values align with the intent of the query?

#### 3. **Contextual Usage**

* [ ] Is this function invoked in a flow or page involved in the **recorded actions**?
* [ ] Can we confirm the **component/page** from which this function is called?

#### 4. **Step Definitions**

* [ ] Are there **step definitions** (e.g. from BDD frameworks like Behave/Cucumber) that use this function?
* [ ] Do the step definitions match the **intent** of the query and the **sequence** in the recorded actions?
* [ ] Can we trace usage of the function in step files or hooks, and does that confirm its purpose?

#### 5. **Comparison with Alternatives**

* [ ] Are there other similar functions? If so, explain **why this function is the best match**.
* [ ] Is there any **ambiguity or uncertainty**? If yes, clearly explain it and how you handled it.

---

### 📥 **Input**

* **Query:** `{query}`
* **Recorded Actions:** `{recorded_actions}`
* **Testcase:** `{testcase}`
---

### 📤 **Output**

* The best-matching function(s)
* Matched step definitions (if any)
* A structured explanation using the checklist above
"""



from code_manager.subgraph.react_llm2 import react_agent

async def main():
    simulation = await react_agent(
        initial_message=prompt,
        system_prompt_template="""
    You are a helpful assistant that helps simulate a user. 
    You will be given a summary of all the answers.
    You need to check if chatbot could have seen the code more throughly then give that instruction to see that to the chatbot.
    

    If the answer is correct then say 'FINISHED' and stop the conversation.""",
        recursion_limit=100
    )

if __name__ == "__main__":
    main()

    