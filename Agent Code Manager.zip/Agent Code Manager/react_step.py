from typing import List, Annotated
from typing_extensions import TypedDict

import os
import json
from dotenv import load_dotenv

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_community.adapters.openai import convert_message_to_dict
from langchain_core.messages import AIMessage, HumanMessage, BaseMessage
from openai import AzureOpenAI

from langgraph.graph import END, StateGraph, START
from langgraph.graph.message import add_messages

from code_manager.llm import llm
from code_manager.prompts import step_function_prompt

from loguru import logger

# Load environment variables
load_dotenv()

# Initialize Azure OpenAI client
model = AzureOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
)

def my_chat_bot(messages: List[dict]) -> dict:
    # logger.debug(f"ChatBot received messages: {messages}")
    system_message = {
        "role": "system",
        "content": "You are a qa engineer expert who can analyse inputs and provide automation scripts. Always respond in JSON format as specified in initial message.",
    }
    messages = [system_message] + messages
    completion = model.chat.completions.create(
        messages=messages, model=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"]
    )
    response = completion.choices[0].message.model_dump()
    logger.debug(f"ChatBot response: {response}")
    return response

system_prompt_template = """
You are a senior QA reviewer working with a conversational AI assistant that generates Cucumber step definitions for a Java Selenium automation project.

Your job is to simulate a QA engineer reviewing the assistant's generated step functions based on:
- A provided feature file (gherkin)
- Existing code snippets and reusable functions from the codebase
- Generated page function files from the assistant previously.

Your responsibilities:

- Ensure each generated step function accurately represents a step from the feature file.
- Confirm the correct use of Cucumber annotations: @Given, @When, @Then.
- Validate that the step function **calls appropriate Page Object methods**, not raw WebDriver code.
- Check method and argument naming for clarity and consistency in both reused page functions and newly generated page functions.
- Review imports and class structure for correctness.
- Detect any steps that are:
    - Missing
    - Incorrectly mapped
    - Duplicated
- Ensure that each gherkin of the feature file is represented by a step function either in the generated code or in the existing code snippets.
- All methods are utilised correctly from the page function files.
- If everything is correct and complete, simply respond with: `FINISHED`.


 **IMPORTANT**:  
If any of the generated annotations (e.g., `@Given("user logs in")`) are already present in the relevant code snippets:
-  Do **not** regenerate that step.
-  Recommend removing it and do not mention it as it is already in repo and will be triggered.

 Provide **concise, constructive feedback** if something needs to be fixed or improved.
Do not write `FINISHED` if the response is incorrect or incomplete by the chatbot.


Be collaborative, but focused on code quality, correctness, reuse, and maintainability.
"""


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", system_prompt_template),
        MessagesPlaceholder(variable_name="messages"),
    ]
)

simulated_user = prompt | llm

def chat_bot_node(state):
    logger.info("chat_bot_node invoked")
    messages = state["messages"]
    messages = [convert_message_to_dict(m) for m in messages]
    chat_bot_response = my_chat_bot(messages)
    # logger.debug(f"chat_bot_node returning: {chat_bot_response['content']}")
    return {"messages": [AIMessage(content=chat_bot_response["content"])]}

def _swap_roles(messages: List[BaseMessage]):
    new_messages = []
    for m in messages:
        if isinstance(m, AIMessage):
            new_messages.append(HumanMessage(content=m.content))
        else:
            new_messages.append(AIMessage(content=m.content))
    return new_messages

def simulated_user_node(state):
    logger.info("simulated_user_node invoked")
    messages = state["messages"]
    new_messages = _swap_roles(messages)
    response = simulated_user.invoke({"messages": new_messages})
    logger.debug(f"simulated_user_node response: {response.content}")
    return {"messages": [HumanMessage(content=response.content)]}

def should_continue(state):
    messages:List[BaseMessage] = state["messages"]
    if len(messages) > 6:
        logger.info("Stopping: Max message limit reached.")
        return "end"
    elif "FINISHED" in messages[-1].content.upper():
        logger.info("Stopping: Conversation finished.")
        return "end"
    else:
        return "continue"

class State(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]

graph_builder = StateGraph(State)
graph_builder.add_node("user", simulated_user_node)
graph_builder.add_node("chat_bot", chat_bot_node)

graph_builder.add_edge("chat_bot", "user")
graph_builder.add_conditional_edges(
    "user",
    should_continue,
    {
        "end": END,
        "continue": "chat_bot",
    },
)
graph_builder.add_edge(START, "chat_bot")
simulation = graph_builder.compile(checkpointer = False)

# Generate and save the graph visualization
# png_bytes = simulation.get_graph().draw_mermaid_png()
# os.makedirs("static", exist_ok=True)
# with open('static/llm_converse_workflow.png', 'wb') as file:
#     file.write(png_bytes)
# logger.info("Saved workflow graph to static/llm_converse_workflow.png")


async def react_step(initial_message: str):
    logger.info("React step function invoked")
    simulation_result = await simulation.ainvoke({"messages": [initial_message]})
    # logger.debug(f"Simulation result: {simulation_result}")
    return simulation_result


if __name__ == "__main__":
    logger.info("Starting simulation...")
    try:
        with open('outputs/test_run.json','r') as f:
            test_run = json.load(f)
            # logger.debug(f"Loaded test run: {test_run}")
    except Exception as e:
        logger.error(f"Failed to load test run: {e}")
        raise

    inputs = {
        "snippets": test_run['relevant_snippets'],
        "page_function_file": test_run['page_functions'],
        # "testcase": test_run['testcase'],
        "feature_files": test_run['feature_files'],
        "project_files": test_run['project_files'][1]
    }

    try:
        initial_message = step_function_prompt.invoke(inputs).text
        # logger.debug(f"Initial message to simulation: {initial_message}")
    except Exception as e:
        logger.error(f"Failed to invoke step_function_prompt: {e}")
        raise

    # for chunk in simulation.stream({"messages": [initial_message]}):
    #     if END not in chunk:
    #         logger.info(f"Simulation step result: {chunk}")
    #         print(chunk)
    #         print("===")

    simulation_result = simulation.invoke({"messages": [initial_message]})

    

    logger.info("Simulation finished.")
