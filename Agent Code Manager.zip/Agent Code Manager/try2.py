# main.py

import os
from loguru import logger
from code_search.tree_sitter_parsers import parse_file

def create_sample_file():
    """
    Creates a simple Python file named 'example.py' with:
      - an import
      - a class
      - two functions
    """
    sample_code = """<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.example</groupId>
  <artifactId>demo-project</artifactId>
  <version>1.0.0</version>
  <packaging>jar</packaging>

  <dependencies>
    <dependency>
      <groupId>org.seleniumhq.selenium</groupId>
      <artifactId>selenium-java</artifactId>
      <version>4.9.0</version>
    </dependency>
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.13.2</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
</project>
"""

    with open("pom.xml", "w", encoding="utf-8") as f:
        f.write(sample_code)
    logger.info("Created 'pom.xml' for parsing demonstration.")

def main():
    # 1. Create a sample file to parse
    create_sample_file()

    # 2. Define which extensions we support
    supported_extensions = [".py", ".js", ".ts", ".java",".xml"]

    # 3. Parse the sample Python file
    logger.info("Parsing 'pom.xml' with Tree-sitter...")
    results = parse_file("pom.xml", supported_extensions)

    # 4. Print out each extracted node
    if not results:
        logger.warning("No relevant nodes found in 'pom.xml'.")
    else:
        print("\nExtracted nodes from pom.xml:\n" + "-" * 40)
        for entry in results:
            node_type = entry["node_type"]
            (start_line, end_line) = entry["lines"]
            snippet = entry["text"]

            print(f"Node type : {node_type}")
            print(f"Lines     : {start_line + 1}–{end_line + 1}")  # +1 for human-readable line numbers
            print("Code snippet:")
            print(snippet)
            print("-" * 40)

    # 5. Clean up the sample file
    try:
        os.remove("pom.xml")
        logger.info("Removed 'pom.xml' after parsing.")
    except Exception as e:
        logger.error(f"Could not delete 'pom.xml': {e}")

if __name__ == "__main__":
    main()
