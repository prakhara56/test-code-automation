# menu_app.py
from loguru import logger
from sentence_transformers import SentenceTransformer
from code_search.repo_indexer import RepoIndexer
from code_search.hybrid_storage import hybrid_load
from code_search.vector_search import search_query, cluster_query

# Import the embed function for indexing
from code_search.embed import do_embed

def menu():
    print("\nSemantic Code Search with Tree-sitter Parsing")
    print("===============================================")
    print("1. Index repository")
    print("2. Search for code")
    print("3. Cluster similar functions")
    print("4. Exit")
    choice = input("Enter your choice (1-4): ").strip()
    return choice

def get_common_repo_input():
    repo = input("Enter repository (Git/azure URL or local path): ").strip()
    clone_dir = input("Enter local directory for cloning the repo (default: repo_clone_dir): ").strip()
    index_path = "Repo_index"
    if not clone_dir:
        clone_dir = "repo_clone_dir"
    # If it's a URL, we'll need to clone it later.
    return repo, clone_dir, index_path

def index_repo(model:SentenceTransformer,model_name:str = ''):
    repo, clone_dir, index_path = get_common_repo_input()
    
    # If repo is a URL, clone it; otherwise, use it directly.
    if repo.startswith("http"):
        indexer = RepoIndexer(repo_url=repo, clone_dir=clone_dir)
        repo_path = indexer.clone_repository()
        indexer.build_index()
        indexer.save_index(f'{index_path}/repo_index.json')
    else:
        repo_path = repo

    # Create a simple args dictionary similar to the argparse Namespace.
    args = {
        "path_to_repo": repo_path,
        "model_name_or_path": model_name,
        "path_to_index": index_path
    }
    print("Indexing repository at:", repo_path)
    x = input("Enter 1 to continue with indexing or 2 to exit here.")
    if x == "1":
        dataset = do_embed(args, model)
        print(f"Indexing and embedding complete. Embeddings generated of {len(dataset)} texts.")
    else:
        print("Exiting indexing without embedding.")

def search_code(model):
    repo, clone_dir, index_path = get_common_repo_input()
    repo = "Repo_Index/.embeddings"
    query_text = input("Enter natural language query for code search: ").strip()
    n_results = input("Enter number of search results to return (default 5): ").strip()
    n_results = int(n_results) if n_results else 5

    args = {
        "path_to_repo": repo,
        "path_to_index": index_path,
        "query_text": query_text,
        "n_results": n_results,
    }

    tree_root, dataset = hybrid_load(args)
    
    
    print("Searching repository at:", repo)
    search_query(args, model, dataset)

def cluster_functions(model):
    repo, clone_dir = get_common_repo_input()
    cluster_max_distance = input("Enter distance threshold for clustering (default 0.5): ").strip()
    cluster_max_distance = float(cluster_max_distance) if cluster_max_distance else 0.5

    if repo.startswith("http"):
        config = {"file_extensions": [".py", ".js", ".ts", ".java"]}
        indexer = RepoIndexer(repo_url=repo, config=config, clone_dir=clone_dir)
        repo_path = indexer.clone_repository()
    else:
        repo_path = repo

    args = {
        "path_to_repo": repo_path,
        "cluster_max_distance": cluster_max_distance
    }
    print("Clustering functions in repository at:", repo_path)
    cluster_query(args, model)

def main():
    # Initialize the SentenceTransformer model.
    model_name_or_path = "model/sentence-t5-base-nlpl-code_search_net"
    model = SentenceTransformer(model_name_or_path)
    

    while True:
        choice = menu()
        if choice == "1":
            print("dwadw")
            index_repo(model,model_name_or_path)
        elif choice == "2":
            print("wadwad")
            search_code(model)
        elif choice == "3":
            cluster_functions(model)
        elif choice == "4":
            print("Exiting the application.")
            break
        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()
