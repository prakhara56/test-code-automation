import json
import os
from typing import List, Dict, Union
from loguru import logger
import asyncio
import time
import sys
import sqlite3
from docx import Document
from langgraph.graph import StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
from langgraph.checkpoint.sqlite import SqliteSaver
# from langgraph.prebuilt import create_react_agent


from code_manager.models import AgentState
from code_manager.utils import save_graph_to_file, add_edges, add_nodes, add_conditional_edges
from code_manager.config import NODES, ENTRY_POINT, EDGES, CONDITIONAL_EDGES
from code_manager.utils import process_recorded_actions
# from code_manager.agents import routing_function

logger.add("logs/user_story_gen.log")

def create_state_graph(
        create_mermaid: bool = False, 
        save_flow_path: str = "static/output.png", 
        db_path: str = "sqlite/code_manager.sqlite",
        async_excecution: bool = False
    ) -> Union[StateGraph,CompiledStateGraph]:
    """Create a StateGraph to model the workflow"""

    workflow = StateGraph(AgentState) 

    workflow = add_nodes(workflow, NODES)
    workflow.set_entry_point(ENTRY_POINT)
    workflow = add_edges(workflow, EDGES)

    if len(CONDITIONAL_EDGES)>0: 
        workflow = add_conditional_edges(workflow, CONDITIONAL_EDGES)

    if async_excecution:
        return workflow
    # Compile and run the workflow with debug messages
    
    conn = sqlite3.connect(db_path)
    checkpointer = SqliteSaver(conn)
    app = workflow.compile(checkpointer=checkpointer)

    if create_mermaid:
        save_graph_to_file(app, save_flow_path)

    return app


async def run_workflow(testcase, recorded_steps, config:Dict = None,continue_excecution:bool =False) -> Dict:

    logger.info("Creating state graph...")
    create_mermaid = False
    app = create_state_graph(create_mermaid=True, async_excecution=True)

    logger.info("Starting workflow execution...")
    initial_state = {
        "testcase": testcase,
        "recorded_steps": process_recorded_actions(recorded_steps),    
        "plan": [],
        "fetched_snippets": [],
        "relevant_snippets": [],
        "project_files": [],
        "feature_files": [],
        "page_functions": [],
        "step_functions": [],
        "clone_dir": config.get('configurable', {}).get('clone_dir', None),
        "repo_name": config.get('configurable', {}).get('repo_name', None)
    }

    if continue_excecution:
        logger.info("Continuing workflow execution...")
        initial_state = None    

    db_path = "sqlite/code_manager.sqlite"
    async with AsyncSqliteSaver.from_conn_string(db_path) as saver:
        try:
            # Run the workflow and observe the debug outputs
            logger.debug("INITIAL State:", initial_state)
            graph = app.compile(checkpointer=saver)
            if create_mermaid:
                save_graph_to_file(graph, "static/workflow.png")

            if create_mermaid:
                logger.info("Saving graph to file...")
                save_graph_to_file(graph, "static/output4",as_save='mermaid')
            result = await graph.ainvoke(initial_state, config = config)
            
            
            logger.info("Workflow execution completed successfully.")

            return result
        except Exception as e:
            # Catch and log the error, then continue with the next request
            logger.error(f"ERROR: Failed to process request")
            logger.error(f"ERROR DETAILS: {str(e)},{sys.exc_info()}", "red")

def read_docx(file_path):
    doc = Document(file_path)
    text = ""
    for paragraph in doc.paragraphs:
        text += paragraph.text + "\n"
    return text

def main(input_path):

    with open(input_path, 'r') as f:
        input = json.load(f)
    
    testcase = input['testcase']
    recorded_steps = input['action_input']
    
    config = {
        "configurable": {
            "thread_id":"mock_run_1",
            'n_search':10,
            'clone_dir': r"C:\Users\prakhar.agarwal\Downloads\repos",
            'repo_name': "BAWTestAutomation",
        }
    }

    output = asyncio.run(run_workflow(testcase, recorded_steps, config, continue_excecution=False))

    return output

if __name__ == "__main__":

    for i in range(18,21):
        input_path = f'inputs/test{i}.json'
        if not os.path.exists(input_path):
            logger.error(f"Input file {input_path} does not exist.")
            continue

        start = time.time()
        result = main(input_path)
        duration = time.time() - start
        logger.info(f"Time taken for {input_path}: {duration:.2f} seconds")

        output_file = f"Outputs1-10/test{i}_output.json"#f"outputs/test{i}_output.json"
        with open(output_file, "w") as file:
            json.dump(result, file, indent=4)
    # start = time.time()
    # result = main(r'inputs\test16.json')
    # duration = time.time() - start
    # logger.info(f"Time taken: {duration:.2f} seconds")

    # # print(result)
    # with open("outputs/test_run.json", "w") as file:
    #     json.dump(result, file, indent=4)