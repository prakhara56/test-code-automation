import re
from typing import TypedDict, List, Dict, Tuple
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END
from code_manager.llm import llm





# ------------------------------
# 1. LLM Model for Evaluation & Refinement
# ------------------------------
# llm = ChatOpenAI(model="gpt-4o", temperature=0)





# ------------------------------
# 2. Code Retrieval Tool
#    This simulated tool returns a tuple: (code_chunk, similarity_score)
#    In your real system, this tool would query your codebase and return the most relevant code chunk.
# ------------------------------
def code_retriever_tool(query: str) -> Tuple[str, float]:
   responses = {
       "Implement login function": ("def login(username, password): ...", 0.95),
       "Use login function in test": ("def test_login(): login('user', 'pass')", 0.93),
       "Extend login function for 2FA": ("def login(credentials: dict, token=None): ...", 0.92),
       "Validate user data": ("def validateUser(data: dict): ...", 0.90),
       # When a query is refined to use an existing function, simulate a higher similarity score.
       "Use pre-implemented function for Implement login function": ("def login(username, password): ...", 0.97),
   }
   # Default response if the query is not found.
   return responses.get(query, ("// No code found", 0.5))





# ------------------------------
# 3. Workflow State Definition
#
#    - recorded_steps: the raw recorded UI steps (requirements) as natural language.
#    - test_cases: expected behaviors.
#    - plan_steps: a list of dictionaries, one per step, with keys:
#         "description": the original UI step.
#         "query": the current natural language query used for code retrieval.
#         "retrieved_code": the code chunk returned by the tool.
#         "similarity": similarity score from the tool.
#         "use_existing": flag (True/False) indicating if we are using a pre-implemented function.
#    - iterations: counter for the number of iterations.
#    - needs_refinement: flag indicating if any step needs further refinement.
#    - global_context: a dictionary tracking pre-implemented function usage (keyed by a unique identifier, here using the step description).
# ------------------------------
class WorkflowState(TypedDict):
   recorded_steps: List[str]
   test_cases: List[str]
   plan_steps: List[Dict]      # Each step is a dict as described above.
   iterations: int
   needs_refinement: bool
   global_context: Dict[str, Dict]  # E.g., {"Implement login function": {"code": code_chunk, "query": ...}}





# ------------------------------
# 4. Agent: Generate Initial Plan
#    Generate a plan from the recorded UI steps.
# ------------------------------
def generate_initial_plan(state: WorkflowState):
   plan = []
   for desc in state["recorded_steps"]:
       plan.append({
           "description": desc,
           "query": desc,            # Start by using the recorded step as the initial query.
           "retrieved_code": "",
           "similarity": 0.0,
           "use_existing": False
       })
   return {
       "plan_steps": plan,
       "global_context": {},   # Start with an empty global context.
       "iterations": 0,
       "needs_refinement": True
   }





# ------------------------------
# 5. Agent: Retrieve Code for Each Plan Step
#    For every plan step, query the retrieval tool.
#    If a similar functionality has already been adopted (tracked in global_context),
#    modify the query to force reuse of the pre-implemented function.
# ------------------------------
def retrieve_code_for_each_step(state: WorkflowState):
   updated_plan = []
   # Copy the current global context.
   global_context = state["global_context"].copy()
   for step in state["plan_steps"]:
       current_query = step["query"]
       # Check if any previously adopted function should be reused.
       # Here we check if any key in global_context is a substring of the step description.
       for ctx_key in global_context.keys():
           if ctx_key.lower() in step["description"].lower():
               current_query = f"Use pre-implemented function for {step['description']}"
               break
       # Query the code retrieval tool.
       code_chunk, sim = code_retriever_tool(current_query)
       step["query"] = current_query
       step["retrieved_code"] = code_chunk
       step["similarity"] = sim
       # Mark this step as using an existing function if similarity is high.
       step["use_existing"] = sim >= 0.9
       updated_plan.append(step)
       # If the step is using an existing function, update the global context.
       if step["use_existing"]:
           # Here we use the step description as a unique key.
           global_context[step["description"]] = {"code": code_chunk, "query": current_query}
   return {
       "plan_steps": updated_plan,
       "global_context": global_context
   }





# ------------------------------
# 6. Agent: Evaluate and Refine the Plan
#    Evaluate each plan step. If the similarity score is low,
#    refine the query (simulate by prefixing "Refine:" to the current query).
# ------------------------------
def evaluate_and_refine_plan(state: WorkflowState):
   refined_plan = []
   needs_refinement = False
   for step in state["plan_steps"]:
       # If the similarity score is below the threshold, refine the query.
       if step["similarity"] < 0.9:
           # Here, we simulate refinement by modifying the query.
           step["query"] = f"Refine: {step['query']}"
           needs_refinement = True
       refined_plan.append(step)
   return {
       "plan_steps": refined_plan,
       "needs_refinement": needs_refinement,
       "iterations": state["iterations"] + 1
   }





# ------------------------------
# 7. Agent: Refinement Decision
#    Determine if further iterations are required.
# ------------------------------
def refinement_decision(state: WorkflowState):
   if state["needs_refinement"] and state["iterations"] < 5:
       return "retrieve_code_for_each_step"
   else:
       return END















# ------------------------------
# 8. Build the LangGraph Workflow
# ------------------------------
workflow = StateGraph(WorkflowState)
workflow.add_node("generate_initial_plan", generate_initial_plan)
workflow.add_node("retrieve_code_for_each_step", retrieve_code_for_each_step)
workflow.add_node("evaluate_and_refine_plan", evaluate_and_refine_plan)
workflow.add_node("refinement_decision", refinement_decision)
workflow.add_edge(START, "generate_initial_plan")
workflow.add_edge("generate_initial_plan", "retrieve_code_for_each_step")
workflow.add_edge("retrieve_code_for_each_step", "evaluate_and_refine_plan")
workflow.add_edge("evaluate_and_refine_plan", "refinement_decision")
workflow.add_conditional_edges("refinement_decision", refinement_decision)
final_workflow = workflow.compile()












# ------------------------------
# 9. Run the Workflow
# ------------------------------
initial_input = {
   "recorded_steps": [
       "Implement login function",
       "Use login function in test",
       "Extend login function for 2FA",
       "Validate user data"
   ],
   "test_cases": [
       "Test login with valid credentials",
       "Test login with invalid credentials"
   ],
   "plan_steps": [],
   "iterations": 0,
   "needs_refinement": True,
   "global_context": {}
}
result = final_workflow.invoke(initial_input)











# ------------------------------
# 10. Final Output
# ------------------------------
print("Finalized Plan Steps:")
for step in result["plan_steps"]:
   print(step)
print("\nGlobal Context (Adopted Pre-Implemented Functions):")
print(result["global_context"])