from code_manager.tools import search_code


ans=search_code.invoke({
    "query_text":"User fill the form"
    })
print(ans)